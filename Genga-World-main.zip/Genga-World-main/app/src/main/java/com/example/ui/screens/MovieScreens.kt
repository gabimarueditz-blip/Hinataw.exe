package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.FavoriteEntity
import com.example.data.local.HistoryEntity
import com.example.data.model.Episode
import com.example.data.model.MovieSubject
import com.example.data.model.StreamItem
import com.example.data.model.SubtitleItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.MovieViewModel
import com.example.ui.viewmodel.ActiveDownload
import kotlinx.coroutines.isActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import android.net.Uri
import android.content.Intent
import com.example.R
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.input.PasswordVisualTransformation
import android.widget.Toast
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures


fun downloadVideo(context: android.content.Context, url: String, title: String, posterUrl: String = "") {
    if (url.isEmpty()) {
        android.widget.Toast.makeText(context, "Stream URL is empty", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val safeTitle = title.replace(Regex("[^a-zA-Z0-9.-]"), "_")
        val manager = context.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as android.app.DownloadManager
        
        if (posterUrl.isNotEmpty()) {
            val safeShowName = Regex("(.*?)(_S\\d+E\\d+.*|$)").find(safeTitle)?.groupValues?.get(1)?.trim() ?: safeTitle

            // 1. Instant Direct HTTP download (saves in 1-2 seconds)
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    val gengaDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "Genga World")
                    if (!gengaDir.exists()) gengaDir.mkdirs()
                    val titlePoster = java.io.File(gengaDir, "$safeTitle.jpg")
                    val showPoster = if (safeShowName.isNotEmpty() && safeShowName != safeTitle) java.io.File(gengaDir, "$safeShowName.jpg") else null

                    val conn = (java.net.URL(posterUrl).openConnection() as java.net.HttpURLConnection).apply {
                        connectTimeout = 6000
                        readTimeout = 6000
                        instanceFollowRedirects = true
                    }
                    if (conn.responseCode in 200..299) {
                        val bytes = conn.inputStream.use { it.readBytes() }
                        if (bytes.isNotEmpty()) {
                            if (!titlePoster.exists()) titlePoster.writeBytes(bytes)
                            if (showPoster != null && !showPoster.exists()) showPoster.writeBytes(bytes)
                        }
                    }
                } catch (e: Exception) { }
            }

            // 2. Also register in DownloadManager as system fallback
            try {
                val posterRequest = android.app.DownloadManager.Request(android.net.Uri.parse(posterUrl))
                posterRequest.setTitle("$title Poster")
                posterRequest.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_HIDDEN)
                posterRequest.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_MOVIES, "Genga World/$safeTitle.jpg")
                manager.enqueue(posterRequest)

                if (safeShowName.isNotEmpty() && safeShowName != safeTitle) {
                    val showPosterFile = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "Genga World/$safeShowName.jpg")
                    if (!showPosterFile.exists()) {
                        val showPosterRequest = android.app.DownloadManager.Request(android.net.Uri.parse(posterUrl))
                        showPosterRequest.setTitle("$safeShowName Poster")
                        showPosterRequest.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_HIDDEN)
                        showPosterRequest.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_MOVIES, "Genga World/$safeShowName.jpg")
                        manager.enqueue(showPosterRequest)
                    }
                }
            } catch (e: Exception) { }
        }

        val request = android.app.DownloadManager.Request(android.net.Uri.parse(url))
        val fileName = "$safeTitle.mp4"
        request.setTitle(title)
        request.setDescription("Downloading...")
        request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_MOVIES, "Genga World/$fileName")
        manager.enqueue(request)
        android.widget.Toast.makeText(context, "Download started...", android.widget.Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Failed to start download: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

object VideoCacheManager {
    @Volatile
    private var simpleCache: androidx.media3.datasource.cache.SimpleCache? = null

    @Synchronized
    fun getCache(context: android.content.Context): androidx.media3.datasource.cache.SimpleCache {
        if (simpleCache == null) {
            val cacheDir = java.io.File(context.cacheDir, "media_video_cache")
            val evictor = androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor(300L * 1024 * 1024) // 300MB fast LRU disk cache
            val databaseProvider = androidx.media3.database.StandaloneDatabaseProvider(context)
            simpleCache = androidx.media3.datasource.cache.SimpleCache(cacheDir, evictor, databaseProvider)
        }
        return simpleCache!!
    }
}

@Composable
fun SplashScreen(
    isReady: Boolean,
    onFinish: () -> Unit
) {
    var startAnimation by remember { mutableStateOf(false) }
    val alphaAnim by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 600),
        label = "splash_fade_in"
    )
    val scaleAnim by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.85f,
        animationSpec = androidx.compose.animation.core.tween(
            durationMillis = 700,
            easing = androidx.compose.animation.core.FastOutSlowInEasing
        ),
        label = "splash_scale"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
    }

    LaunchedEffect(isReady) {
        val startTime = System.currentTimeMillis()
        val minDisplayTimeMs = 850L
        val maxWaitTimeMs = 2000L // Safety timeout: never trap or freeze the user

        while (isActive) {
            val elapsed = System.currentTimeMillis() - startTime
            if (isReady && elapsed >= minDisplayTimeMs) {
                onFinish()
                break
            }
            if (elapsed >= maxWaitTimeMs) {
                // Timeout safety exit: proceed to Home screen even if network is slow
                onFinish()
                break
            }
            delay(50L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF140204),
                        ObsidianDark,
                        Color(0xFF07080D)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .alpha(alphaAnim)
                .scale(scaleAnim)
        ) {
            // App Icon in clean circular frame
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(ObsidianCard)
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = R.drawable.ic_launcher_fg),
                    contentDescription = "Genga World Logo",
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Cinematic App Title
            Text(
                text = "GENGA WORLD",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Stream Endless Cinema",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                letterSpacing = 1.5.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Smooth sleek loading bar
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = CinematicRed,
                strokeWidth = 2.dp
            )
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MovieBoxApp(viewModel: MovieViewModel) {
    val trending by viewModel.trendingMovies.collectAsState()
    val categoryMovies by viewModel.categoryMovies.collectAsState()
    val isContentReady = remember(trending, categoryMovies, viewModel.isDashboardLoading) {
        (trending.isNotEmpty() || categoryMovies.isNotEmpty()) && !viewModel.isDashboardLoading
    }

    var showSplash by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(true) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        AnimatedContent(
            targetState = showSplash,
            transitionSpec = {
                fadeIn(animationSpec = tween(400)) with
                fadeOut(animationSpec = tween(400))
            },
            label = "splash_to_main_transition"
        ) { isSplashVisible ->
            if (isSplashVisible) {
                SplashScreen(
                    isReady = isContentReady,
                    onFinish = { showSplash = false }
                )
            } else {
                MainContent(viewModel)
            }
        }
    }
}

@Composable
fun LockoutScreen(viewModel: MovieViewModel) {
    var passwordInput by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF140204),
                        ObsidianDark
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Earth/Globe Icon that represents geofencing
            Icon(
                imageVector = Icons.Filled.PublicOff,
                contentDescription = "Geofenced",
                tint = CinematicRed,
                modifier = Modifier
                    .size(96.dp)
                    .padding(bottom = 16.dp)
            )

            Text(
                text = "Service Restriction",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Clickable text to unlock developer mode
            Text(
                text = "This application is not available in your current region.",
                fontSize = 15.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .clickable(onClick = {
                        viewModel.passwordAttempts++
                        if (viewModel.passwordAttempts >= 10) {
                            viewModel.showPasswordDialog = true
                        }
                    })
                    .testTag("lockout_message")
            )

            Spacer(modifier = Modifier.height(40.dp))

            // User friendly help block for development environments
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "STUDIO EMULATOR MODE ACTIVE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentAmber,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "To bypass geographic carrier restrictions, tap the message above 10 times and enter security access key or use the Auto-Bypass below.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.submitDeveloperPassword("or666")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auto_bypass_button")
                    ) {
                        Icon(Icons.Filled.Terminal, contentDescription = "Bypass", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Auto-Bypass Lockout", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Lab password popup dialog
        if (viewModel.showPasswordDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.showPasswordDialog = false },
                title = { Text("Laboratory Security Gateway", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Enter decryption or bypass developer credentials:", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Gateway Key") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = CinematicRed,
                                unfocusedBorderColor = TextSecondary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("password_input")
                        )
                        if (loginError) {
                            Text("Invalid security key. Hint: 'or666'", color = CinematicRed, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val success = viewModel.submitDeveloperPassword(passwordInput)
                            if (success) {
                                loginError = false
                            } else {
                                loginError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CinematicRed)
                    ) {
                        Text("Verify Key")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.showPasswordDialog = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                },
                containerColor = ObsidianCard
            )
        }
    }
}

@Composable
fun TelegramJoinDialog(
    onDismiss: () -> Unit,
    telegramUrl: String = "https://t.me/Gengaworldofficial"
) {
    val context = LocalContext.current

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1F24)),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // App Logo
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_fg),
                    contentDescription = "Genga World Logo",
                    modifier = Modifier.size(68.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Title
                Text(
                    text = "Join the Genga Family",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Subtitle / Description
                Text(
                    text = "Be a special member of our Telegram family \u2014 get early access, request titles, and hear about new features first.",
                    color = Color(0xFFB0B3B8),
                    fontSize = 13.5.sp,
                    lineHeight = 19.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Button: Join Telegram
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open Telegram: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA2DE))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Send,
                        contentDescription = "Telegram",
                        tint = Color.White,
                        modifier = Modifier
                            .size(18.dp)
                            .rotate(-25f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Join Telegram",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Dismiss: Maybe later
                TextButton(
                    onClick = onDismiss
                ) {
                    Text(
                        text = "Maybe later",
                        color = Color(0xFF8E8E93),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun ForceUpdateFullScreen(
    updateInfo: com.example.ui.viewmodel.MovieViewModel.AppUpdateInfo,
    isDownloading: Boolean,
    progress: Int,
    statusText: String,
    onUpdateClick: () -> Unit,
    onGoToDownloads: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // App Logo with glowing red pulse
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(CinematicRed.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_fg),
                    contentDescription = "Genga World",
                    modifier = Modifier.size(56.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Update Required to Continue",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Version ${updateInfo.latestVersionName} is now available",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = CinematicRed
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "What's New in this update:",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = updateInfo.changelog.ifEmpty { "Critical improvements, stream playback fixes, and security updates." },
                        color = Color(0xFFB0B3B8),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            if (isDownloading) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LinearProgressIndicator(
                        progress = { if (progress > 0) progress / 100f else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CinematicRed,
                        trackColor = Color(0xFF333338)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (statusText.isNotEmpty()) "Downloading: $statusText" else "Downloading update...",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            } else {
                Button(
                    onClick = onUpdateClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CinematicRed)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = "Download",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Update Now",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedButton(
                    onClick = onGoToDownloads,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF3A3B40))
                ) {
                    Icon(
                        imageVector = Icons.Filled.DownloadDone,
                        contentDescription = "Offline Downloads",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Watch Offline Downloads",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun AppUpdateDialog(
    updateInfo: com.example.ui.viewmodel.MovieViewModel.AppUpdateInfo,
    isDownloading: Boolean,
    progress: Int,
    statusText: String,
    onUpdateClick: () -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = {
            if (!isDownloading) onDismiss()
        },
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = !isDownloading,
            dismissOnClickOutside = !isDownloading,
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1F24)),
            elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // App Logo / Update Icon
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0xFF0EA2DE).copy(alpha = 0.15f), shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.SystemUpdate,
                        contentDescription = "Update",
                        tint = Color(0xFF0EA2DE),
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "New Version Available",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Version ${updateInfo.latestVersionName}",
                    color = CinematicRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                if (updateInfo.changelog.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = updateInfo.changelog,
                            color = Color(0xFFB0B3B8),
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "A new update is available with improvements and fixes.",
                        color = Color(0xFFB0B3B8),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                if (isDownloading) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LinearProgressIndicator(
                            progress = { if (progress > 0) progress / 100f else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = CinematicRed,
                            trackColor = Color(0xFF333338)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (statusText.isNotEmpty()) "Downloading: $statusText" else "Downloading update...",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Button(
                        onClick = onUpdateClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA2DE))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = "Download",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Download & Install",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = "Later",
                            color = Color(0xFF8E8E93),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainContent(viewModel: MovieViewModel) {
    var activeTab by remember { mutableStateOf("home") } // home, search, watchlist, history, account
    val updateInfo = viewModel.availableUpdateInfo
    val isForceUpdateActive = updateInfo?.isForceUpdate == true
    var forceUpdateAllowDownloadsOnly by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("app_settings_prefs", android.content.Context.MODE_PRIVATE) }
    val lastShownMillis = remember { prefs.getLong("last_telegram_prompt_timestamp", 0L) }
    val cooldownPeriodMillis = 168L * 60 * 60 * 1000 // 168 hours (7 days)
    val shouldPromptTelegram = remember { (System.currentTimeMillis() - lastShownMillis) >= cooldownPeriodMillis }
    var showTelegramDialog by rememberSaveable { mutableStateOf(shouldPromptTelegram) }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                if (viewModel.playInfo == null && viewModel.playingDownloadedFile == null) {
                    NavigationBar(
                        containerColor = ObsidianDark,
                        tonalElevation = 8.dp
                    ) {
                        if (!isForceUpdateActive) {
                            NavigationBarItem(
                                selected = activeTab == "home",
                                onClick = { activeTab = "home" },
                                icon = { Icon(if (activeTab == "home") Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinematicRed,
                                    selectedTextColor = CinematicRed,
                                    indicatorColor = ObsidianCard,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = activeTab == "search",
                                onClick = { activeTab = "search" },
                                icon = { Icon(if (activeTab == "search") Icons.Filled.Search else Icons.Outlined.Search, contentDescription = "Search") },
                                label = { Text("Search", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinematicRed,
                                    selectedTextColor = CinematicRed,
                                    indicatorColor = ObsidianCard,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_search")
                            )
                            NavigationBarItem(
                                selected = activeTab == "watchlist",
                                onClick = { activeTab = "watchlist" },
                                icon = { Icon(if (activeTab == "watchlist") Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, contentDescription = "Watchlist") },
                                label = { Text("Watchlist", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinematicRed,
                                    selectedTextColor = CinematicRed,
                                    indicatorColor = ObsidianCard,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_watchlist")
                            )
                        }

                        NavigationBarItem(
                            selected = activeTab == "download",
                            onClick = { activeTab = "download" },
                            icon = { Icon(if (activeTab == "download") Icons.Filled.Download else Icons.Outlined.Download, contentDescription = "Download") },
                            label = { Text("Download", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CinematicRed,
                                selectedTextColor = CinematicRed,
                                indicatorColor = ObsidianCard,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_download")
                        )

                        if (!isForceUpdateActive) {
                            NavigationBarItem(
                                selected = activeTab == "settings",
                                onClick = { activeTab = "settings" },
                                icon = { Icon(if (activeTab == "settings") Icons.Filled.Settings else Icons.Outlined.Settings, contentDescription = "Settings") },
                                label = { Text("Settings", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinematicRed,
                                    selectedTextColor = CinematicRed,
                                    indicatorColor = ObsidianCard,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (activeTab) {
                    "home" -> HomeScreen(viewModel)
                    "search" -> SearchScreen(viewModel)
                    "watchlist" -> WatchlistScreen(viewModel)
                    "download" -> DownloadScreen(viewModel)
                    "settings" -> SettingsScreen(
                        viewModel, 
                        onNavigateToHistory = { activeTab = "history" },
                        onNavigateToManageCategories = { activeTab = "manage_categories" }
                    )
                    "manage_categories" -> ManageCategoriesScreen(
                        viewModel,
                        onBack = { activeTab = "settings" }
                    )
                    "history" -> HistoryScreen(viewModel)
                }
            }
        }



        // Detail screen slide-up overlay
        AnimatedVisibility(
            visible = viewModel.selectedSubject != null,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300))
        ) {
            DetailScreen(viewModel)
        }

        // Simulated Video Player overlay
        AnimatedVisibility(
            visible = viewModel.playInfo != null,
            enter = fadeIn(animationSpec = tween(250)),
            exit = fadeOut(animationSpec = tween(250))
        ) {
            PlayerScreen(viewModel)
        }

        // Offline Download Video Player overlay
        AnimatedVisibility(
            visible = viewModel.playingDownloadedFile != null,
            enter = fadeIn(animationSpec = tween(250)),
            exit = fadeOut(animationSpec = tween(250))
        ) {
            val file = viewModel.playingDownloadedFile
            if (file != null) {
                OfflinePlayerScreen(
                    fileToPlay = file,
                    onDismiss = { viewModel.playingDownloadedFile = null }
                )
            }
        }

        // Playback loading overlay
        if (viewModel.isPlaybackLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(enabled = false) {}, // block all clicks while loading
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = CinematicRed)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Fetching stream links...",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // In-App Smart/Force Update Screen
        val updateInfo = viewModel.availableUpdateInfo
        if (updateInfo != null && viewModel.playInfo == null) {
            if (updateInfo.isForceUpdate) {
                if (activeTab != "download") {
                    ForceUpdateFullScreen(
                        updateInfo = updateInfo,
                        isDownloading = viewModel.isDownloadingUpdate,
                        progress = viewModel.updateDownloadProgress,
                        statusText = viewModel.updateStatusMessage,
                        onUpdateClick = {
                            viewModel.downloadAndInstallUpdate(context, updateInfo.downloadUrl)
                        },
                        onGoToDownloads = {
                            activeTab = "download"
                        }
                    )
                }
            } else {
                AppUpdateDialog(
                    updateInfo = updateInfo,
                    isDownloading = viewModel.isDownloadingUpdate,
                    progress = viewModel.updateDownloadProgress,
                    statusText = viewModel.updateStatusMessage,
                    onUpdateClick = {
                        viewModel.downloadAndInstallUpdate(context, updateInfo.downloadUrl)
                    },
                    onDismiss = {
                        android.preference.PreferenceManager.getDefaultSharedPreferences(context)
                            .edit()
                            .putLong("last_update_dismissed_timestamp", System.currentTimeMillis())
                            .apply()
                        viewModel.availableUpdateInfo = null
                    }
                )
            }
        }

        // Telegram Channel Welcome Popup on App Open (168-hour cooldown)
        if (showTelegramDialog && viewModel.playInfo == null && updateInfo == null) {
            TelegramJoinDialog(
                onDismiss = {
                    prefs.edit().putLong("last_telegram_prompt_timestamp", System.currentTimeMillis()).apply()
                    showTelegramDialog = false
                },
                telegramUrl = "https://t.me/Gengaworldofficial"
            )
        }
    }
}

fun Modifier.shimmerEffect(): Modifier = composed {
    var size by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val transition = rememberInfiniteTransition(label = "shimmer")
    val startOffsetX by transition.animateFloat(
        initialValue = -2 * size.width.toFloat(),
        targetValue = 2 * size.width.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    background(
        brush = Brush.linearGradient(
            colors = listOf(
                Color(0xFF1E1E22),
                Color(0xFF2E2E32),
                Color(0xFF1E1E22),
            ),
            start = Offset(startOffsetX, 0f),
            end = Offset(startOffsetX + size.width.toFloat(), size.height.toFloat())
        )
    ).onGloballyPositioned {
        size = it.size
    }
}

@Composable
fun DashboardShimmerScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        // Shimmer Hero Banner Placeholder
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .shimmerEffect()
            ) {
                // Bottom shading gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, ObsidianDark)
                            )
                        )
                )
                
                // Text lines placeholders
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(80.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .shimmerEffect()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(28.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .shimmerEffect()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.4f)
                            .height(16.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .shimmerEffect()
                    )
                }
            }
        }

        // Horizontal Row Placeholder 1
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Box(
                    modifier = Modifier
                        .padding(start = 16.dp, bottom = 12.dp)
                        .width(140.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerEffect()
                )
                
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(6) {
                        Column(modifier = Modifier.width(110.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(165.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .shimmerEffect()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .height(14.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .shimmerEffect()
                            )
                        }
                    }
                }
            }
        }

        // Category Filter Chips placeholder
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(4) {
                    Box(
                        modifier = Modifier
                            .width(90.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .shimmerEffect()
                    )
                }
            }
        }

        // Grid items placeholder
        items(3) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                repeat(3) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .shimmerEffect()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerEffect()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: MovieViewModel) {
    val trending by viewModel.trendingMovies.collectAsState()
    val categoryMovies by viewModel.categoryMovies.collectAsState()

    val context = LocalContext.current
    val imageLoader = remember(context) { coil.Coil.imageLoader(context) }

    // Prioritize and immediately start loading top hero banner and top row images first
    LaunchedEffect(categoryMovies, trending) {
        val topBannerPosters = categoryMovies.take(3).mapNotNull { it.poster.takeIf { p -> p.isNotBlank() } }
        val topTrendingPosters = trending.take(6).mapNotNull { it.poster.takeIf { p -> p.isNotBlank() } }
        val priorityPosters = (topBannerPosters + topTrendingPosters).distinct()

        for (url in priorityPosters) {
            val req = coil.request.ImageRequest.Builder(context)
                .data(url)
                .memoryCacheKey(url)
                .diskCacheKey(url)
                .build()
            imageLoader.enqueue(req)
        }
    }

    if (viewModel.isDashboardLoading) {
        DashboardShimmerScreen()
    } else {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        // Hero Slider/Banner Section (Auto-cycling Carousel)
        if (categoryMovies.isNotEmpty()) {
            item {
                val bannerMovies = categoryMovies.take(5)
                val pagerState = androidx.compose.foundation.pager.rememberPagerState(pageCount = { bannerMovies.size })
                
                LaunchedEffect(pagerState, bannerMovies) {
                    while (bannerMovies.isNotEmpty()) {
                        kotlinx.coroutines.delay(4000)
                        val nextPage = (pagerState.currentPage + 1) % bannerMovies.size
                        pagerState.animateScrollToPage(nextPage)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                ) {
                    androidx.compose.foundation.pager.HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize()
                    ) { page ->
                        val heroMovie = bannerMovies[page]
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable { viewModel.selectSubject(heroMovie) }
                        ) {
                            AsyncImage(
                                model = coil.request.ImageRequest.Builder(LocalContext.current)
                                    .data(heroMovie.poster)
                                    .memoryCacheKey(heroMovie.poster)
                                    .diskCacheKey(heroMovie.poster)
                                    .crossfade(false)
                                    .build(),
                                contentDescription = heroMovie.name,
                                contentScale = ContentScale.Crop,
                                placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                modifier = Modifier.fillMaxSize()
                            )
                            // Gradient shading
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                ObsidianDark
                                            )
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomStart)
                                    .padding(20.dp)
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = CinematicRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = "TRENDING",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = heroMovie.name,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = heroMovie.genres.joinToString(" • "),
                                    fontSize = 13.sp,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row {
                                    Button(
                                        onClick = { viewModel.selectSubject(heroMovie) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = "Play")
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Details & Play", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Horizontal list of Trending items (without "Editor's Choice" label)
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(trending) { movie ->
                        MovieGridItem(movie, showRating = true) {
                            viewModel.selectSubject(movie)
                        }
                    }
                }
            }
        }

        // Horizontal Category filter chips (without "Explore Categories" label)
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                val categories by viewModel.activeCategories.collectAsState()

                LaunchedEffect(categories) {
                    if (categories.isNotEmpty() && categories.none { it.first == viewModel.selectedCategoryTab }) {
                        viewModel.loadCategoryList(categories.first().first)
                    }
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = if (categories.size <= 4) Arrangement.SpaceBetween else Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = viewModel.selectedCategoryTab == cat.first,
                            onClick = { viewModel.loadCategoryList(cat.first) },
                            label = { Text(cat.second) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CinematicRed,
                                selectedLabelColor = Color.White,
                                containerColor = ObsidianCard,
                                labelColor = TextSecondary
                            ),
                            border = null
                        )
                    }
                }
            }
        }

        // Category Movies Grid list
        items(categoryMovies.chunked(3)) { rowMovies ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowMovies.forEach { movie ->
                    Box(modifier = Modifier.weight(1f)) {
                        MovieGridItem(movie) {
                            viewModel.selectSubject(movie)
                        }
                    }
                }
                // Fill up remaining grid slots
                if (rowMovies.size < 3) {
                    repeat(3 - rowMovies.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Bottom space padding
        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
    }
}

@Composable
fun MovieGridItem(movie: MovieSubject, showRating: Boolean = false, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(110.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .height(160.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            AsyncImage(
                model = coil.request.ImageRequest.Builder(LocalContext.current)
                    .data(movie.poster)
                    .memoryCacheKey(movie.poster)
                    .diskCacheKey(movie.poster)
                    .crossfade(false)
                    .build(),
                contentDescription = movie.name,
                contentScale = ContentScale.Crop,
                placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                modifier = Modifier.fillMaxSize()
            )
            // Rating Tag
            if (showRating) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Star, contentDescription = "Rating", tint = AccentAmber, modifier = Modifier.size(10.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(movie.rating, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = movie.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = movie.year,
            fontSize = 11.sp,
            color = TextSecondary
        )
    }
}

@Composable
fun SearchScreen(viewModel: MovieViewModel) {
    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    val results by viewModel.searchResults.collectAsState()
    var searchInput by remember { mutableStateOf(viewModel.searchQuery) }
    var isSearchSubmitted by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel.customCountryIso) {
        viewModel.loadSearchSuggestions()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchInput,
            onValueChange = {
                searchInput = it
                isSearchSubmitted = false
                viewModel.searchMovies(it)
            },
            placeholder = { Text("Search", color = TextSecondary) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextSecondary) },
            trailingIcon = {
                if (searchInput.isNotEmpty()) {
                    IconButton(onClick = {
                        searchInput = ""
                        isSearchSubmitted = false
                        viewModel.searchMovies("")
                    }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(
                onSearch = {
                    isSearchSubmitted = true
                    focusManager.clearFocus()
                }
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = ObsidianCard,
                unfocusedContainerColor = ObsidianCard,
                focusedBorderColor = CinematicRed,
                unfocusedBorderColor = Color.Transparent
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        val suggestions by viewModel.searchSuggestions.collectAsState()

        if (viewModel.isSearching) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CinematicRed)
            }
        } else if (!isSearchSubmitted || searchInput.isEmpty()) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    Text(
                        text = if (searchInput.isEmpty()) "Trending Searches" else "Suggestions",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }
                
                itemsIndexed(suggestions) { index, suggestion ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                searchInput = suggestion
                                isSearchSubmitted = true
                                viewModel.searchMovies(suggestion)
                                focusManager.clearFocus()
                            }
                            .background(ObsidianCard, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (searchInput.isEmpty()) {
                            Text(
                                text = "${index + 1}",
                                color = if (index < 3) CinematicRed else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                modifier = Modifier.width(32.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "Suggestion",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                        }
                        Text(
                            text = suggestion,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (searchInput.isEmpty()) {
                            Icon(
                                imageVector = Icons.Filled.TrendingUp,
                                contentDescription = "Trending",
                                tint = if (index < 3) CinematicRed else TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        } else if (results.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.SearchOff, contentDescription = "No Results", tint = TextSecondary, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No results found", color = TextSecondary, fontSize = 15.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(results) { movie ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                focusManager.clearFocus()
                                viewModel.selectSubject(movie)
                            }
                            .background(ObsidianCard, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = movie.poster,
                            contentDescription = movie.name,
                            contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                            modifier = Modifier
                                .size(width = 60.dp, height = 90.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(movie.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(movie.genres.joinToString(", "), fontSize = 13.sp, color = TextSecondary)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Star, contentDescription = "Rating", tint = AccentAmber, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(movie.rating, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(movie.year, fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WatchlistScreen(viewModel: MovieViewModel) {
    val favorites by viewModel.favoritesList.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refreshWatchlist()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(16.dp)
    ) {
        Text("My Watchlist", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.padding(bottom = 16.dp))

        if (favorites.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.BookmarkAdd, contentDescription = "Watchlist empty", tint = TextSecondary, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Your watchlist is empty", color = TextSecondary, fontSize = 15.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(favorites) { movie ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                // Maps entities back to subjects
                                val subject = MovieSubject(
                                    id = movie.id,
                                    name = movie.name,
                                    poster = movie.poster,
                                    isTvShow = movie.isTvShow,
                                    rating = movie.rating,
                                    year = movie.year
                                )
                                viewModel.selectSubject(subject)
                            }
                            .background(ObsidianCard, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = movie.poster,
                            contentDescription = movie.name,
                            contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                            modifier = Modifier
                                .size(width = 50.dp, height = 75.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(movie.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(movie.year + " • " + if (movie.isTvShow) "TV Show" else "Movie", fontSize = 13.sp, color = TextSecondary)
                        }
                        IconButton(onClick = {
                            val subject = MovieSubject(id = movie.id, name = movie.name, poster = movie.poster)
                            viewModel.toggleFavorite(subject)
                        }) {
                            Icon(Icons.Filled.BookmarkRemove, contentDescription = "Remove", tint = CinematicRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(viewModel: MovieViewModel) {
    val history by viewModel.historyList.collectAsState()
    var expandedSubjectId by remember { mutableStateOf<String?>(null) }

    val groupedHistory = remember(history) {
        history.groupBy { it.subjectId }.map { entry ->
            entry.value.first() to entry.value
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(16.dp)
    ) {
        Text("Continue Watching", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.padding(bottom = 16.dp))

        if (groupedHistory.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.PlayCircleOutline, contentDescription = "History empty", tint = TextSecondary, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No playback history available", color = TextSecondary, fontSize = 15.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(groupedHistory) { (item, episodesList) ->
                    val isExpanded = expandedSubjectId == item.subjectId

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ObsidianCard, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (item.isTvShow) {
                                        expandedSubjectId = if (isExpanded) null else item.subjectId
                                    } else {
                                        // Movie: play directly
                                        val subject = MovieSubject(
                                            id = item.subjectId,
                                            name = item.name,
                                            poster = item.poster,
                                            isTvShow = item.isTvShow
                                        )
                                        viewModel.selectSubject(subject)
                                        viewModel.selectMovieDirect()
                                    }
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = item.poster,
                                contentDescription = item.name,
                                contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                modifier = Modifier
                                    .size(width = 60.dp, height = 90.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(modifier = Modifier.height(4.dp))
                                if (item.isTvShow) {
                                    Text(
                                        text = "${episodesList.size} episodes watched • Tap to view",
                                        fontSize = 13.sp,
                                        color = AccentAmber,
                                        fontWeight = FontWeight.Medium
                                    )
                                } else {
                                    val percentage = if (item.totalTime > 0) (item.seeTime.toFloat() / item.totalTime.toFloat()) else 0f
                                    val formattedProgress = formatTime(item.seeTime) + " / " + formatTime(item.totalTime)
                                    Text(formattedProgress, fontSize = 12.sp, color = TextSecondary)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = percentage.coerceIn(0f, 1f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = CinematicRed,
                                        trackColor = Color.Gray.copy(alpha = 0.3f)
                                    )
                                }
                            }
                            IconButton(onClick = {
                                episodesList.forEach { viewModel.deleteHistoryItem(it.id) }
                            }) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete All", tint = TextSecondary)
                            }
                        }

                        if (item.isTvShow && isExpanded) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp, start = 16.dp, end = 8.dp)
                                    .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                episodesList.forEach { epItem ->
                                    val percentage = if (epItem.totalTime > 0) (epItem.seeTime.toFloat() / epItem.totalTime.toFloat()) else 0f
                                    val formattedProgress = formatTime(epItem.seeTime) + " / " + formatTime(epItem.totalTime)

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                val subject = MovieSubject(
                                                    id = epItem.subjectId,
                                                    name = epItem.name,
                                                    poster = epItem.poster,
                                                    isTvShow = epItem.isTvShow
                                                )
                                                viewModel.selectSubject(subject)
                                                val episode = Episode(
                                                    episodeId = epItem.id,
                                                    title = "Season ${epItem.season} Episode ${epItem.episode}",
                                                    episodeNumber = epItem.episode,
                                                    seasonNumber = epItem.season
                                                )
                                                viewModel.selectEpisode(episode)
                                            }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Season ${epItem.season} Ep ${epItem.episode}", fontSize = 13.sp, color = AccentAmber, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(formattedProgress, fontSize = 11.sp, color = TextSecondary)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            LinearProgressIndicator(
                                                progress = percentage.coerceIn(0f, 1f),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(3.dp)
                                                    .clip(RoundedCornerShape(1.dp)),
                                                color = CinematicRed,
                                                trackColor = Color.Gray.copy(alpha = 0.3f)
                                            )
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteHistoryItem(epItem.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabScreen(viewModel: MovieViewModel) {
    var hostText by remember { mutableStateOf(viewModel.mockHost) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.Science, contentDescription = "Laboratory", tint = AccentAmber, modifier = Modifier.size(56.dp))
        Spacer(modifier = Modifier.height(8.dp))
        Text("BFF Laboratory Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("Sandbox & geofencing simulator config", fontSize = 13.sp, color = TextSecondary)

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Simulate Region Carrier Settings", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Overrides SIM parameters in API handshake headers", fontSize = 12.sp, color = TextSecondary)

                Spacer(modifier = Modifier.height(16.dp))

                // Region choices matching protocol Section 9
                val regions = listOf(
                    Triple("90101", "us", "United States (Global)"),
                    Triple("40401", "in", "India (Hindi Dubs)"),
                    Triple("62101", "ng", "Nigeria (Nollywood)")
                )

                regions.forEach { reg ->
                    val isSelected = viewModel.customMcc == reg.first && viewModel.customCountryIso == reg.second
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.applyCustomSandbox(reg.first, reg.second) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.applyCustomSandbox(reg.first, reg.second) },
                            colors = RadioButtonDefaults.colors(selectedColor = CinematicRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(reg.third, color = TextPrimary, fontSize = 14.sp)
                            Text("MCC: ${reg.first} | ISO: ${reg.second}", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("BFF Proxy Host Configuration", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Route API traffic through your custom cloud instance", fontSize = 12.sp, color = TextSecondary)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = hostText,
                    onValueChange = { hostText = it },
                    label = { Text("Server Host URL") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CinematicRed,
                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f),
                        focusedLabelColor = CinematicRed,
                        cursorColor = CinematicRed
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("mock_host_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val defaultHost = "http://127.0.0.1:3000"
                            hostText = defaultHost
                            viewModel.updateMockHost(defaultHost)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.2f)),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("Local Server", color = AccentAmber, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            hostText = "http://127.0.0.1:3000"
                            viewModel.updateMockHost("http://127.0.0.1:3000")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.2f)),
                        modifier = Modifier.weight(0.8f)
                    ) {
                        Text("Default Local", color = Color.White, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        viewModel.updateMockHost(hostText.trim())
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save & Apply Host", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { viewModel.resetSandbox() },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Re-Lock Sandbox & Exit Lab", color = CinematicRed, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DetailScreen(viewModel: MovieViewModel) {
    val subject = viewModel.selectedSubject ?: return
    val isFav by viewModel.isFavoriteFlow(subject.id).collectAsState(false)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            // Backdrop and poster cover
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    AsyncImage(
                        model = subject.poster,
                        contentDescription = subject.name,
                        contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                        modifier = Modifier.fillMaxSize()
                    )
                    // Backdrop gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.5f),
                                        ObsidianDark
                                    )
                                )
                            )
                    )

                    // Close Button
                    IconButton(
                        onClick = { viewModel.selectedSubject = null },
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(top = 16.dp, start = 16.dp)
                            .align(Alignment.TopStart)
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                            .testTag("detail_close_button")
                    ) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            }

            // Title block
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = subject.name,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.toggleFavorite(subject) }) {
                            Icon(
                                imageVector = if (isFav) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Favorite",
                                tint = if (isFav) CinematicRed else TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, contentDescription = "Rating", tint = AccentAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(subject.rating, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Text(subject.year, color = TextSecondary, fontSize = 14.sp)
                        Text(subject.duration, color = TextSecondary, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Genres row
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        subject.genres.forEach { gen ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = gen,
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Description text
                    Text(
                        text = subject.description.ifEmpty { "No description available for this item." },
                        fontSize = 14.sp,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )

                    // Live Cast Section
                    if (subject.cast.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Cast",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(bottom = 16.dp)
                        ) {
                            items(subject.cast) { actor ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(80.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(ObsidianCard)
                                    ) {
                                        if (actor.avatar.isNotEmpty()) {
                                            coil.compose.AsyncImage(
                                                model = actor.avatar,
                                                contentDescription = actor.name,
                                                contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Person,
                                                    contentDescription = "Avatar placeholder",
                                                    tint = TextSecondary,
                                                    modifier = Modifier.size(28.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = actor.name,
                                        fontSize = 11.sp,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Text(
                                        text = actor.role.ifEmpty { "Cast" },
                                        fontSize = 9.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }

                    // More Like This Section
                    if (viewModel.detailRecommendations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "More Like This",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(bottom = 16.dp)
                        ) {
                            items(viewModel.detailRecommendations) { movie ->
                                MovieGridItem(movie) {
                                    viewModel.selectSubject(movie)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Action buttons
                    if (!subject.isTvShow) {
                        Button(
                            onClick = { viewModel.selectMovieDirect() },
                            colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("play_movie_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Play")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Stream Movie in High Definition", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    } else {
                        Text(
                            text = "Seasons",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Season Selector Horizontal chips
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 20.dp)
                        ) {
                            items(viewModel.seasonsList) { s ->
                                FilterChip(
                                    selected = viewModel.selectedSeason == s,
                                    onClick = { viewModel.loadEpisodesForSeason(s) },
                                    label = { Text("Season $s") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CinematicRed,
                                        selectedLabelColor = Color.White,
                                        containerColor = ObsidianCard,
                                        labelColor = TextSecondary
                                    ),
                                    border = null
                                )
                            }
                        }
                    }
                }
            }

            // TV Show Episodes List Section
            if (subject.isTvShow) {
                items(viewModel.episodesList) { ep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp)
                            .clickable { viewModel.selectEpisode(ep) }
                            .background(ObsidianCard, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = ep.stillPath.ifEmpty { subject.poster },
                            contentDescription = ep.title,
                            contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                            modifier = Modifier
                                .size(width = 80.dp, height = 50.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Episode ${ep.episodeNumber}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentAmber
                            )
                            Text(
                                text = ep.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(Icons.Filled.PlayCircleFilled, contentDescription = "Play", tint = CinematicRed, modifier = Modifier.size(32.dp))
                    }
                }
            }

            // Bottom space
            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun PlayerScreen(viewModel: MovieViewModel) {
    val playInfo = viewModel.playInfo ?: return
    val subject = viewModel.selectedSubject ?: return
    val context = LocalContext.current

    val selectedStream = viewModel.selectedStream
    val rawUrl = selectedStream?.url ?: ""
    val streamUrl = if (rawUrl == "https://macdn.aoneroom.com/other/2026/09/04/b164fbfb4347792950bdfbfb563d39d9.mp4") "" else rawUrl
    val selectedCookie = selectedStream?.cookie ?: ""
    val subtitleUrl = viewModel.selectedSubtitle?.url

    var activeSheet by remember { mutableStateOf<String?>(null) }
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val screenHeight = configuration.screenHeightDp.dp
    val isFullscreen = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val playerHeight = minOf(screenWidth * (9f / 16f), screenHeight * 0.32f)
    var isControllerVisible by remember { mutableStateOf(true) }

    // Double-tap Gesture Indicator States
    var doubleTapActionText by remember { mutableStateOf<String?>(null) }
    var doubleTapActionSide by remember { mutableStateOf<String?>(null) } // "left", "center", "right"
    var gestureAnimTrigger by remember { mutableStateOf(0L) }

    // Initialize Media3 ExoPlayer
    val exoPlayer = remember {
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
            
        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context).apply {
            setMediaCodecSelector { mimeType, requiresSecure, requiresTunneling ->
                val decoders = androidx.media3.exoplayer.mediacodec.MediaCodecUtil.getDecoderInfos(mimeType, requiresSecure, requiresTunneling)
                decoders.sortedWith { d1, d2 ->
                    val n1 = d1.name.lowercase()
                    val n2 = d2.name.lowercase()
                    val sw1 = n1.contains("google") || n1.contains("c2.android") || n1.contains("sw")
                    val sw2 = n2.contains("google") || n2.contains("c2.android") || n2.contains("sw")
                    when {
                        sw1 && !sw2 -> -1
                        !sw1 && sw2 -> 1
                        else -> 0
                    }
                }
            }
        }
        
        // Dynamic Hardware-Based Buffering (Vega-Style)
        val activityManager = context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val memoryInfo = android.app.ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val totalRamBytes = memoryInfo.totalMem
        val heapLimitBytes = activityManager.memoryClass * 1024L * 1024L
        
        val safeBufferBytes = minOf(
            (heapLimitBytes * 0.35).toLong(),
            (totalRamBytes / 32)
        ).toInt()
        val targetBufferBytes = safeBufferBytes.coerceAtLeast(32 * 1024 * 1024) // Fallback to 32MB min
        
        val allocator = androidx.media3.exoplayer.upstream.DefaultAllocator(true, androidx.media3.common.C.DEFAULT_BUFFER_SEGMENT_SIZE)
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(
                25000,   // minBufferMs (25 seconds minimum buffer before idle)
                120000,  // maxBufferMs (2 minutes max buffer limit)
                1000,    // bufferForPlaybackMs (Only 1.0 second needed to start instantly!)
                2000     // bufferForPlaybackAfterRebufferMs (Only 2.0 seconds needed to recover)
            )
            .setTargetBufferBytes(targetBufferBytes) // Dynamically calculated safe limit
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(30000, true) // Keep 30 seconds of previous video in RAM
            .build()

        ExoPlayer.Builder(context)
            .setRenderersFactory(renderersFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .build().apply {
                playWhenReady = viewModel.isPlaying
            }
    }

    // Sync native playlist next/prev buttons transitions with ViewModel selections
    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                viewModel.isPlaying = playWhenReady
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem != null && mediaItem.localConfiguration?.uri?.toString() == "http://dummy.mp4") {
                    val targetEpisodeId = mediaItem.mediaId
                    val targetEpisode = viewModel.episodesList.find { it.episodeId == targetEpisodeId }
                    if (targetEpisode != null) {
                        viewModel.selectEpisode(targetEpisode)
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    var currentProgressMs by remember { mutableStateOf(viewModel.playbackProgressMs) }
    var durationMs by remember { mutableStateOf(viewModel.mediaDurationMs) }

    // Update stream and subtitle configuration
    LaunchedEffect(streamUrl, subtitleUrl) {
        if (streamUrl.isNotEmpty()) {
            val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setUserAgent("MovieBoxPro/16.2.1 (Android 14; com.community.mbox.in)")
                .setAllowCrossProtocolRedirects(true)
            
            if (selectedCookie.isNotEmpty()) {
                httpDataSourceFactory.setDefaultRequestProperties(mapOf("Cookie" to selectedCookie))
            }

            // Wrap with on-disk LRU media cache for zero-stutter seeks and zero repeated downloads
            val cacheDataSourceFactory = androidx.media3.datasource.cache.CacheDataSource.Factory()
                .setCache(VideoCacheManager.getCache(context))
                .setUpstreamDataSourceFactory(httpDataSourceFactory)
                .setFlags(androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

            val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(streamUrl))
            if (!subtitleUrl.isNullOrEmpty()) {
                val mimeType = if (subtitleUrl.endsWith(".vtt", ignoreCase = true)) {
                    MimeTypes.TEXT_VTT
                } else {
                    MimeTypes.APPLICATION_SUBRIP
                }
                val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(subtitleUrl))
                    .setMimeType(mimeType)
                    .setLanguage(viewModel.selectedSubtitle?.language ?: "en")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                mediaItemBuilder.setSubtitleConfigurations(listOf(subtitleConfig))
            }

            val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(
                cacheDataSourceFactory,
                androidx.media3.extractor.DefaultExtractorsFactory()
            )
            val mediaSource = mediaSourceFactory.createMediaSource(mediaItemBuilder.build())

            val currentEpisode = viewModel.currentEpisode
            val episodes = viewModel.episodesList
            if (subject.isTvShow && episodes.isNotEmpty() && currentEpisode != null) {
                val currentIndex = episodes.indexOfFirst { it.episodeId == currentEpisode.episodeId }
                if (currentIndex != -1) {
                    val mediaSources = episodes.map { ep ->
                        if (ep.episodeId == currentEpisode.episodeId) {
                            mediaSource
                        } else {
                            mediaSourceFactory.createMediaSource(
                                MediaItem.Builder()
                                    .setMediaId(ep.episodeId)
                                    .setUri(Uri.parse("http://dummy.mp4"))
                                    .build()
                            )
                        }
                    }
                    exoPlayer.setMediaSources(mediaSources, currentIndex, viewModel.playbackProgressMs)
                } else {
                    exoPlayer.setMediaSource(mediaSource)
                }
            } else {
                exoPlayer.setMediaSource(mediaSource)
            }
            exoPlayer.prepare()
            if (viewModel.playbackProgressMs > 0) {
                exoPlayer.seekTo(viewModel.playbackProgressMs)
            }
            if (viewModel.isPlaying) {
                exoPlayer.play()
            }
        }
    }

    // Play/Pause sync
    LaunchedEffect(viewModel.isPlaying) {
        if (viewModel.isPlaying != exoPlayer.playWhenReady) {
            exoPlayer.playWhenReady = viewModel.isPlaying
        }
    }

    // Buffering listener
    var isBuffering by remember { mutableStateOf(false) }
    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == androidx.media3.common.Player.STATE_BUFFERING)
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    // Auto-hide controller when playing
    LaunchedEffect(isControllerVisible, viewModel.isPlaying) {
        if (isControllerVisible && viewModel.isPlaying) {
            delay(4000)
            isControllerVisible = false
        }
    }

    // Speed sync
    var selectedSpeed by remember { mutableStateOf(1.0f) }
    LaunchedEffect(selectedSpeed) {
        exoPlayer.setPlaybackSpeed(selectedSpeed)
    }

    // Dynamic resolution constraint selector
    LaunchedEffect(selectedStream) {
        val q = selectedStream?.quality ?: "Auto"
        val (maxWidth, maxHeight) = when {
            q.contains("1080") -> Pair(1920, 1080)
            q.contains("720") -> Pair(1280, 720)
            q.contains("480") -> Pair(854, 480)
            q.contains("360") -> Pair(640, 360)
            else -> Pair(Integer.MAX_VALUE, Integer.MAX_VALUE)
        }
        try {
            val builder = exoPlayer.trackSelectionParameters.buildUpon()
            if (q == "Auto") {
                builder.clearVideoSizeConstraints()
                builder.setForceHighestSupportedBitrate(false)
            } else {
                builder.setMaxVideoSize(maxWidth, maxHeight)
                // Force ExoPlayer to pick the highest possible quality within this cap immediately
                // instead of waiting for adaptive bandwidth estimation to trigger a switch
                builder.setForceHighestSupportedBitrate(true)
            }
            exoPlayer.trackSelectionParameters = builder.build()
        } catch (e: Exception) {
            // Log fallback or safety
        }
    }

    // Listen to player progress ticking
    LaunchedEffect(viewModel.isPlaying) {
        if (viewModel.isPlaying) {
            while (true) {
                val pos = exoPlayer.currentPosition
                val dur = exoPlayer.duration
                if (dur > 0) {
                    currentProgressMs = pos
                    durationMs = dur
                    viewModel.updatePlaybackProgress(pos, dur)
                }
                delay(1000)
            }
        }
    }

    DisposableEffect(Unit) {
        val activity = context as? android.app.Activity
        activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        onDispose {
            exoPlayer.release()
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val activity = context as? android.app.Activity
    val isInPip = activity?.isInPictureInPictureMode ?: false

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(if (!isFullscreen) Modifier.statusBarsPadding() else Modifier)
        ) {

            // Player Container (Always present in tree at index 0)
        Box(
            modifier = if (isFullscreen || isInPip) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .fillMaxWidth()
                    .height(playerHeight)
            }
        ) {
            if (streamUrl.isNotEmpty()) {
                AndroidView(
                    factory = { ctx ->
                        val view = android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.texture_player_view, null) as androidx.media3.ui.PlayerView
                        view.keepScreenOn = true
                        view.isHapticFeedbackEnabled = false
                        view.isSoundEffectsEnabled = false
                        view.layoutParams = android.view.ViewGroup.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        view.apply {
                            subtitleView?.setViewType(androidx.media3.ui.SubtitleView.VIEW_TYPE_CANVAS)
                            val cleanStyle = androidx.media3.ui.CaptionStyleCompat(
                                android.graphics.Color.WHITE,
                                android.graphics.Color.TRANSPARENT,
                                android.graphics.Color.TRANSPARENT,
                                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                android.graphics.Color.BLACK,
                                null
                            )
                            subtitleView?.setStyle(cleanStyle)
                        }
                    },
                    update = { view ->
                        if (view.player != exoPlayer) {
                            view.player = exoPlayer
                        }
                    },
                    onRelease = { view ->
                        view.player = null
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Universal Gestures Layer (Single tap toggles UI, Double tap Left = -5s, Center = Pause/Play, Right = +10s)
                val density = androidx.compose.ui.platform.LocalDensity.current
                val coroutineScope = rememberCoroutineScope()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = {
                                    isControllerVisible = !isControllerVisible
                                },
                                onDoubleTap = { tapOffset: androidx.compose.ui.geometry.Offset ->
                                    val width = size.width.toFloat()
                                    val x = tapOffset.x
                                    val leftBoundary = width * 0.35f
                                    val rightBoundary = width * 0.65f

                                    when {
                                        x < leftBoundary -> {
                                            // Left side: rewind 5 seconds
                                            val current = exoPlayer.currentPosition
                                            val target = (current - 5000L).coerceAtLeast(0L)
                                            exoPlayer.seekTo(target)
                                            doubleTapActionSide = "left"
                                            doubleTapActionText = "-5s"
                                            gestureAnimTrigger = System.currentTimeMillis()
                                        }
                                        x > rightBoundary -> {
                                            // Right side: forward 10 seconds
                                            val current = exoPlayer.currentPosition
                                            val dur = exoPlayer.duration
                                            val target = if (dur > 0) (current + 10000L).coerceAtMost(dur) else current + 10000L
                                            exoPlayer.seekTo(target)
                                            doubleTapActionSide = "right"
                                            doubleTapActionText = "+10s"
                                            gestureAnimTrigger = System.currentTimeMillis()
                                        }
                                        else -> {
                                            // Center: toggle play / pause (stop video)
                                            if (exoPlayer.isPlaying) {
                                                exoPlayer.pause()
                                                viewModel.isPlaying = false
                                                doubleTapActionSide = "center"
                                                doubleTapActionText = "PAUSE"
                                            } else {
                                                exoPlayer.play()
                                                viewModel.isPlaying = true
                                                doubleTapActionSide = "center"
                                                doubleTapActionText = "PLAY"
                                            }
                                            gestureAnimTrigger = System.currentTimeMillis()
                                        }
                                    }
                                }
                            )
                        }
                )

                // Double-Tap Animated Feedback Badges
                LaunchedEffect(gestureAnimTrigger) {
                    if (gestureAnimTrigger > 0L) {
                        delay(750)
                        doubleTapActionSide = null
                        doubleTapActionText = null
                    }
                }

                androidx.compose.animation.AnimatedVisibility(
                    visible = doubleTapActionSide != null,
                    enter = fadeIn(tween(150)) + scaleIn(tween(150)),
                    exit = fadeOut(tween(250)),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (doubleTapActionSide) {
                            "left" -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(0.38f)
                                        .align(Alignment.CenterStart)
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(Color.White.copy(alpha = 0.22f), Color.Transparent)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            Icons.Filled.Replay5,
                                            contentDescription = "Rewind 5s",
                                            tint = Color.White,
                                            modifier = Modifier.size(46.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = doubleTapActionText ?: "-5s",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            "right" -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(0.38f)
                                        .align(Alignment.CenterEnd)
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(Color.Transparent, Color.White.copy(alpha = 0.22f))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            Icons.Filled.Forward10,
                                            contentDescription = "Forward 10s",
                                            tint = Color.White,
                                            modifier = Modifier.size(46.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = doubleTapActionText ?: "+10s",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            "center" -> {
                                Box(
                                    modifier = Modifier
                                        .size(80.dp)
                                        .align(Alignment.Center)
                                        .background(Color.Black.copy(alpha = 0.65f), shape = RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            if (viewModel.isPlaying) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                            contentDescription = "Play/Pause Toggle",
                                            tint = Color.White,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Text(
                                            text = doubleTapActionText ?: "",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Custom Compose Playback Controller Overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = isControllerVisible && !isInPip,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Top Bar: Back button on the left, Settings gear on the right
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopStart)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent)
                                    )
                                )
                                .statusBarsPadding()
                                .clickable(enabled = false) {} // block click-through
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(onClick = {
                                viewModel.playInfo = null
                                val activity = context as? android.app.Activity
                                if (activity != null) {
                                    activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                    activity.window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
                                }
                            }) {
                                Icon(
                                    Icons.Filled.ArrowBack,
                                    contentDescription = "Close Player",
                                    tint = Color.White
                                )
                            }
                            
                            // Top Right Icons: Download and Settings Gear
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val safeTitle = if (subject.isTvShow) {
                                        "${subject.name} S${viewModel.selectedSeason}E${viewModel.currentEpisode?.episodeNumber}"
                                    } else {
                                        subject.name
                                    }
                                    downloadVideo(context, streamUrl, safeTitle, subject.poster)
                                }) {
                                    Icon(
                                        Icons.Filled.Download,
                                        contentDescription = "Download Video",
                                        tint = Color.White
                                    )
                                }
                                
                                IconButton(onClick = {
                                    activeSheet = "player_settings"
                                }) {
                                    Icon(
                                        Icons.Filled.Settings,
                                        contentDescription = "Player Settings",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        // Center Buffering Spinner (if loading)
                        if (isBuffering) {
                            CircularProgressIndicator(
                                color = CinematicRed,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(48.dp)
                            )
                        }

                        // Bottom Controls Row: Play/Pause, Seekbar, Duration, PIP, Fullscreen
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomStart)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))
                                    )
                                )
                                .navigationBarsPadding()
                                .clickable(enabled = false) {} // block click-through
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Play/Pause Button
                            IconButton(
                                onClick = {
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                        viewModel.isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        viewModel.isPlaying = true
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    if (viewModel.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // Progress Slider
                            Slider(
                                value = currentProgressMs.toFloat(),
                                onValueChange = { currentProgressMs = it.toLong() },
                                onValueChangeFinished = { exoPlayer.seekTo(currentProgressMs) },
                                valueRange = 0f..maxOf(1f, durationMs.toFloat()),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = Color.White,
                                    inactiveTrackColor = Color.Gray.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )

                            // Position / Duration text (e.g. 00:03/02:05)
                            Text(
                                text = "${formatTime(currentProgressMs)}/${formatTime(durationMs)}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            // PIP Button
                            IconButton(
                                onClick = {
                                    val activity = context as? android.app.Activity
                                    if (activity != null) {
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                            activity.enterPictureInPictureMode(
                                                android.app.PictureInPictureParams.Builder().build()
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Filled.PictureInPicture,
                                    contentDescription = "PiP Mode",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Fullscreen Toggle Button
                            IconButton(
                                onClick = {
                                    val activity = context as? android.app.Activity
                                    if (activity != null) {
                                        if (!isFullscreen) {
                                            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            activity.window.decorView.systemUiVisibility = (
                                                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                            )
                                        } else {
                                            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            activity.window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
                                        }
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                                    contentDescription = "Toggle Fullscreen",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                    }
                }
            }
        }

                // Transparent click catcher overlay on player view when bottom sheet is active
                if (activeSheet != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable { activeSheet = null }
                    )
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = CinematicRed)
                }
            }
        }

        // Portrait Details panel scroll container at bottom (only in portrait mode)
        if (!isFullscreen && !isInPip) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                    // Player Controller Panels (Subtitles, Dubs & Resolutions)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ObsidianDark)
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (activeSheet != null) {
                        Column(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Header row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when (activeSheet) {
                                        "player_settings" -> "Playback Settings"
                                        "language" -> "Select language"
                                        "season" -> "${viewModel.seasonsList.size} seasons"
                                        "subtitle" -> "Select subtitle"
                                        "quality" -> "Select quality"
                                        "speed" -> "Playback speed"
                                        "episodes" -> "All episodes"
                                        else -> ""
                                    },
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE2E8F0)
                                )
                                IconButton(onClick = { activeSheet = null }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                                }
                            }
                            
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 12.dp),
                                color = Color.Gray.copy(alpha = 0.2f)
                            )
                            
                            if (activeSheet == "player_settings") {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // 0. Cast to TV
                                    var castButton by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<androidx.mediarouter.app.MediaRouteButton?>(null) }
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { castButton?.performClick() }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Tv, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Cast to TV", color = Color.White, fontSize = 14.sp)
                                            AndroidView(
                                                factory = { ctx ->
                                                    val themeCtx = android.view.ContextThemeWrapper(ctx, androidx.appcompat.R.style.Theme_AppCompat)
                                                    androidx.mediarouter.app.MediaRouteButton(themeCtx).apply {
                                                        com.google.android.gms.cast.framework.CastButtonFactory.setUpMediaRouteButton(themeCtx, this)
                                                        castButton = this
                                                        alpha = 0f
                                                    }
                                                },
                                                modifier = Modifier.size(1.dp)
                                            )
                                        }
                                        Text("Not connected", color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 1. Audio Dub Language
                                    val currentDub = viewModel.selectedResource?.name ?: "Original"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activeSheet = "language" }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Audio Dub Language", color = Color.White, fontSize = 14.sp)
                                        }
                                        Text(currentDub, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 2. Subtitles
                                    val currentSub = viewModel.selectedSubtitle?.language ?: "Off"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activeSheet = "subtitle" }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.ClosedCaption, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Subtitles", color = Color.White, fontSize = 14.sp)
                                        }
                                        Text(currentSub, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 3. Playback Speed
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activeSheet = "speed" }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Speed, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Playback Speed", color = Color.White, fontSize = 14.sp)
                                        }
                                        Text("${selectedSpeed}x", color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 4. Video Quality
                                    val currentQuality = viewModel.selectedStream?.quality ?: "Auto"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activeSheet = "quality" }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Settings, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Video Quality", color = Color.White, fontSize = 14.sp)
                                        }
                                        Text(currentQuality, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 5. Episodes List
                                    if (subject.isTvShow) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { activeSheet = "episodes" }
                                                .padding(vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Filled.MenuBook, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text("Episodes List", color = Color.White, fontSize = 14.sp)
                                            }
                                            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                            } else {
                                val itemsList = when (activeSheet) {
                                    "language" -> subject.resourceDetectors
                                    "season" -> viewModel.seasonsList
                                    "subtitle" -> listOf("None") + playInfo.subTitleList.map { it.language }
                                    "quality" -> playInfo.streamList
                                    "speed" -> listOf("0.5x", "0.75x", "1.0x (Normal)", "1.25x", "1.5x", "2.0x")
                                    "episodes" -> viewModel.episodesList
                                    else -> emptyList()
                                }
                                
                                val cols = if (activeSheet == "episodes") 4 else 2
                                val chunked = itemsList.chunked(cols)
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    chunked.forEach { rowItems ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            rowItems.forEach { item ->
                                                val isSelected = when (activeSheet) {
                                                    "language" -> viewModel.selectedResource == item
                                                    "season" -> viewModel.selectedSeason == item
                                                    "subtitle" -> if (item == "None") viewModel.selectedSubtitle == null else viewModel.selectedSubtitle?.language == item
                                                    "quality" -> viewModel.selectedStream == item
                                                    "speed" -> {
                                                        val currentSpeed = exoPlayer.playbackParameters.speed
                                                        val itemSpeed = when (item as String) {
                                                            "0.5x" -> 0.5f
                                                            "0.75x" -> 0.75f
                                                            "1.0x (Normal)" -> 1.0f
                                                            "1.25x" -> 1.25f
                                                            "1.5x" -> 1.5f
                                                            "2.0x" -> 2.0f
                                                            else -> 1.0f
                                                        }
                                                        Math.abs(currentSpeed - itemSpeed) < 0.05f
                                                    }
                                                    "episodes" -> viewModel.currentEpisode?.episodeId == (item as com.example.data.model.Episode).episodeId
                                                    else -> false
                                                }
                                                
                                                Button(
                                                    onClick = {
                                                        when (activeSheet) {
                                                            "language" -> viewModel.selectLanguageResource(item as com.example.data.model.ResourceDetector)
                                                            "season" -> viewModel.loadEpisodesForSeason(item as Int)
                                                            "subtitle" -> {
                                                                if (item == "None") {
                                                                    viewModel.selectedSubtitle = null
                                                                } else {
                                                                    val found = playInfo.subTitleList.find { it.language == item }
                                                                    if (found != null) viewModel.selectedSubtitle = found
                                                                }
                                                            }
                                                            "quality" -> {
                                                                viewModel.selectedStream = item as com.example.data.model.StreamItem
                                                            }
                                                            "speed" -> {
                                                                val speedVal = when (item as String) {
                                                                    "0.5x" -> 0.5f
                                                                    "0.75x" -> 0.75f
                                                                    "1.0x (Normal)" -> 1.0f
                                                                    "1.25x" -> 1.25f
                                                                    "1.5x" -> 1.5f
                                                                    "2.0x" -> 2.0f
                                                                    else -> 1.0f
                                                                }
                                                                selectedSpeed = speedVal
                                                            }
                                                            "episodes" -> {
                                                                viewModel.selectEpisode(item as com.example.data.model.Episode)
                                                            }
                                                        }
                                                        activeSheet = null
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = if (isSelected) Color(0xFF115E59) else Color(0xFF2D2D30)
                                                    ),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(48.dp)
                                                ) {
                                                    Text(
                                                        text = when (activeSheet) {
                                                            "language" -> (item as com.example.data.model.ResourceDetector).name
                                                            "season" -> "Season ${(item as Int).toString().padStart(2, '0')}"
                                                            "subtitle" -> item as String
                                                            "quality" -> (item as com.example.data.model.StreamItem).quality
                                                            "speed" -> item as String
                                                            "episodes" -> (item as com.example.data.model.Episode).episodeNumber.toString().padStart(2, '0')
                                                            else -> ""
                                                        },
                                                        color = if (isSelected) Color(0xFF2DD4BF) else Color.White,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                            if (rowItems.size < cols) {
                                                Spacer(modifier = Modifier.weight((cols - rowItems.size).toFloat()))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {

                        // Resource and Season selectors section
                        Text(
                            text = "Resource / Season",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(bottom = 16.dp)
                        ) {
                            // Resource trigger button
                            if (subject.resourceDetectors.isNotEmpty()) {
                                Button(
                                    onClick = { activeSheet = "language" },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2D2D30)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    val currentDub = viewModel.selectedResource?.name ?: "Original Audio"
                                    Text(
                                        text = "$currentDub ▾",
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            // Season trigger button (only for TV Shows)
                            if (subject.isTvShow && viewModel.seasonsList.isNotEmpty()) {
                                Button(
                                    onClick = { activeSheet = "season" },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2D2D30)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "Season ${viewModel.selectedSeason.toString().padStart(2, '0')} ▾",
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        // Episodes Grid list
                        if (subject.isTvShow) {
                            val chunkedEp = viewModel.episodesList.chunked(4)
                            Column(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                chunkedEp.forEach { rowItems ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        rowItems.forEach { ep ->
                                            val isCurrentEp = viewModel.currentEpisode?.episodeId == ep.episodeId
                                            Card(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(48.dp)
                                                    .clickable { viewModel.selectEpisode(ep) },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isCurrentEp) Color(0xFF115E59) else Color(0xFF2E2E30)
                                                )
                                            ) {
                                                Box(
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = ep.episodeNumber.toString().padStart(2, '0'),
                                                        color = if (isCurrentEp) Color(0xFF2DD4BF) else Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp
                                                    )
                                                }
                                            }
                                        }
                                        // Handle odd items padding
                                        if (rowItems.size < 4) {
                                            Spacer(modifier = Modifier.weight((4 - rowItems.size).toFloat()))
                                        }
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }

        } // Close screen-wrapping Column

        // Custom Slide-Up 2-Column Grid Bottom Sheet Overlay (Root Level)
        if (activeSheet != null && isFullscreen) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable { activeSheet = null }
            ) {
                val isPlayerSheet = isFullscreen && (activeSheet == "subtitle" || activeSheet == "quality" || activeSheet == "speed" || activeSheet == "language" || activeSheet == "episodes" || activeSheet == "season" || activeSheet == "player_settings")
                Card(
                    modifier = Modifier
                        .align(if (isPlayerSheet) Alignment.Center else Alignment.BottomCenter)
                        .padding(if (isPlayerSheet) 24.dp else 0.dp)
                        .fillMaxWidth(if (isPlayerSheet) 0.6f else 1f)
                        .clickable(enabled = false) {}, // prevent click-through
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E20)),
                    shape = if (isPlayerSheet) RoundedCornerShape(16.dp) else RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        // Header row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (activeSheet) {
                                    "player_settings" -> "Playback Settings"
                                    "language" -> "Select language"
                                    "season" -> "${viewModel.seasonsList.size} seasons"
                                    "subtitle" -> "Select subtitle"
                                    "quality" -> "Select quality"
                                    "speed" -> "Playback speed"
                                    "episodes" -> "All episodes"
                                    else -> ""
                                },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE2E8F0)
                            )
                            IconButton(onClick = { activeSheet = null }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                            }
                        }
                        
                        if (activeSheet == "player_settings") {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // 0. Cast to TV
                                var castButton2 by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<androidx.mediarouter.app.MediaRouteButton?>(null) }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { castButton2?.performClick() }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Tv, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text("Cast to TV", color = Color.White, fontSize = 14.sp)
                                        AndroidView(
                                            factory = { ctx ->
                                                val themeCtx = android.view.ContextThemeWrapper(ctx, androidx.appcompat.R.style.Theme_AppCompat)
                                                androidx.mediarouter.app.MediaRouteButton(themeCtx).apply {
                                                    com.google.android.gms.cast.framework.CastButtonFactory.setUpMediaRouteButton(themeCtx, this)
                                                    castButton2 = this
                                                    alpha = 0f
                                                }
                                            },
                                            modifier = Modifier.size(1.dp)
                                        )
                                    }
                                    Text("Not connected", color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 1. Audio Dub Language
                                val currentDub = viewModel.selectedResource?.name ?: "Original"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSheet = "language" }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text("Audio Dub Language", color = Color.White, fontSize = 14.sp)
                                    }
                                    Text(currentDub, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 2. Subtitles
                                val currentSub = viewModel.selectedSubtitle?.language ?: "Off"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSheet = "subtitle" }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.ClosedCaption, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text("Subtitles", color = Color.White, fontSize = 14.sp)
                                    }
                                    Text(currentSub, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 3. Playback Speed
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSheet = "speed" }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Speed, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text("Playback Speed", color = Color.White, fontSize = 14.sp)
                                    }
                                    Text("${selectedSpeed}x", color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 4. Quality Resolution
                                val currentQuality = viewModel.selectedStream?.quality ?: "Auto"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSheet = "quality" }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Settings, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text("Video Quality", color = Color.White, fontSize = 14.sp)
                                    }
                                    Text(currentQuality, color = CinematicRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 5. Episodes List (if TV Show)
                                if (subject.isTvShow) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activeSheet = "episodes" }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.MenuBook, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text("Episodes List", color = Color.White, fontSize = 14.sp)
                                        }
                                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        } else {
                            // Scrollable Option Grid list (2-column or 4-column depending on sheet type)
                            val itemsList = when (activeSheet) {
                                        "language" -> subject.resourceDetectors
                                        "season" -> viewModel.seasonsList
                                        "subtitle" -> listOf("None") + playInfo.subTitleList.map { it.language }
                                        "quality" -> playInfo.streamList
                                        "speed" -> listOf("0.5x", "0.75x", "1.0x (Normal)", "1.25x", "1.5x", "2.0x")
                                        "episodes" -> viewModel.episodesList
                                        else -> emptyList()
                                    }
                            
                            val cols = if (activeSheet == "episodes") 4 else 2
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val chunked = itemsList.chunked(cols)
                            items(chunked.size) { index ->
                                val rowItems = chunked[index]
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    rowItems.forEach { item ->
                                        val isSelected = when (activeSheet) {
                                            "language" -> viewModel.selectedResource == item
                                            "season" -> viewModel.selectedSeason == item
                                            "subtitle" -> if (item == "None") viewModel.selectedSubtitle == null else viewModel.selectedSubtitle?.language == item
                                            "quality" -> viewModel.selectedStream == item
                                            "speed" -> {
                                                val currentSpeed = exoPlayer.playbackParameters.speed
                                                val itemSpeed = when (item as String) {
                                                    "0.5x" -> 0.5f
                                                    "0.75x" -> 0.75f
                                                    "1.0x (Normal)" -> 1.0f
                                                    "1.25x" -> 1.25f
                                                    "1.5x" -> 1.5f
                                                    "2.0x" -> 2.0f
                                                    else -> 1.0f
                                                }
                                                Math.abs(currentSpeed - itemSpeed) < 0.05f
                                            }
                                            "episodes" -> viewModel.currentEpisode?.episodeId == (item as com.example.data.model.Episode).episodeId
                                            else -> false
                                        }
                                        
                                        Button(
                                            onClick = {
                                                when (activeSheet) {
                                                    "language" -> viewModel.selectLanguageResource(item as com.example.data.model.ResourceDetector)
                                                    "season" -> viewModel.loadEpisodesForSeason(item as Int)
                                                    "subtitle" -> {
                                                        if (item == "None") {
                                                            viewModel.selectedSubtitle = null
                                                        } else {
                                                            val found = playInfo.subTitleList.find { it.language == item }
                                                            if (found != null) viewModel.selectedSubtitle = found
                                                        }
                                                    }
                                                    "quality" -> {
                                                        viewModel.selectedStream = item as com.example.data.model.StreamItem
                                                    }
                                                    "speed" -> {
                                                        val speedVal = when (item as String) {
                                                            "0.5x" -> 0.5f
                                                            "0.75x" -> 0.75f
                                                            "1.0x (Normal)" -> 1.0f
                                                            "1.25x" -> 1.25f
                                                            "1.5x" -> 1.5f
                                                            "2.0x" -> 2.0f
                                                            else -> 1.0f
                                                        }
                                                        selectedSpeed = speedVal
                                                    }
                                                    "episodes" -> {
                                                        viewModel.selectEpisode(item as com.example.data.model.Episode)
                                                    }
                                                }
                                                activeSheet = null
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSelected) Color(0xFF115E59) else Color(0xFF2D2D30)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                        ) {
                                            Text(
                                                text = when (activeSheet) {
                                                    "language" -> (item as com.example.data.model.ResourceDetector).name
                                                    "season" -> "Season ${(item as Int).toString().padStart(2, '0')}"
                                                    "subtitle" -> item as String
                                                    "quality" -> (item as com.example.data.model.StreamItem).quality
                                                    "speed" -> item as String
                                                    "episodes" -> (item as com.example.data.model.Episode).episodeNumber.toString().padStart(2, '0')
                                                    else -> ""
                                                },
                                                color = if (isSelected) Color(0xFF2DD4BF) else Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                    // Handle odd elements padding
                                    if (rowItems.size < cols) {
                                        Spacer(modifier = Modifier.weight((cols - rowItems.size).toFloat()))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

// Human readable time formatter helper (mm:ss)
fun formatTime(milliseconds: Long): String {
    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}

data class VideoPlayerOption(
    val name: String,
    val packageName: String,
    val activityName: String?,
    val icon: android.graphics.drawable.Drawable?
)

fun getInstalledVideoPlayers(context: android.content.Context): List<VideoPlayerOption> {
    val pm = context.packageManager
    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
        setDataAndType(android.net.Uri.parse("content://dummy/video.mp4"), "video/*")
    }
    val resolveInfos = try {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, android.content.pm.PackageManager.ResolveInfoFlags.of(android.content.pm.PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            pm.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        }
    } catch (e: Exception) {
        emptyList()
    }
    
    return resolveInfos
        .filter { it.activityInfo != null && it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
            VideoPlayerOption(
                name = it.loadLabel(pm)?.toString() ?: it.activityInfo.packageName,
                packageName = it.activityInfo.packageName,
                activityName = it.activityInfo.name,
                icon = try { it.loadIcon(pm) } catch (e: Exception) { null }
            )
        }
}

fun openInExternalPlayer(context: android.content.Context, file: java.io.File, option: VideoPlayerOption?) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            file
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/*")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (option != null && option.activityName != null) {
                setClassName(option.packageName, option.activityName)
            }
        }
        if (option != null) {
            context.startActivity(intent)
        } else {
            val chooser = android.content.Intent.createChooser(intent, "Play with...")
            context.startActivity(chooser)
        }
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Unable to play: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadScreen(viewModel: MovieViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var hasPermission by remember { 
        mutableStateOf(
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R || 
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) 
    }

    val downloadedFiles = viewModel.downloadedFiles
    val activeDownloads = viewModel.activeDownloads
    val isScanLoaded = viewModel.isDownloadScanLoaded
    var expandedShows by remember { mutableStateOf(setOf<String>()) }
    var playerPickerFile by remember { mutableStateOf<java.io.File?>(null) }

    LaunchedEffect(hasPermission) {
        if (!hasPermission) {
            val activity = context as? android.app.Activity
            if (activity != null && android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
                androidx.core.app.ActivityCompat.requestPermissions(activity, arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 101)
            }
        }
        
        // Background polling loop on Dispatchers.IO - keeps UI 100% fluid with zero lag
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val manager = context.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as? android.app.DownloadManager
            while (isActive) {
                val currentActive = mutableListOf<ActiveDownload>()
                if (manager != null) {
                    try {
                        val query = android.app.DownloadManager.Query().setFilterByStatus(
                            android.app.DownloadManager.STATUS_RUNNING or 
                            android.app.DownloadManager.STATUS_PENDING or 
                            android.app.DownloadManager.STATUS_PAUSED
                        )
                        manager.query(query)?.use { cursor ->
                            val idIdx = cursor.getColumnIndex(android.app.DownloadManager.COLUMN_ID)
                            val titleIdx = cursor.getColumnIndex(android.app.DownloadManager.COLUMN_TITLE)
                            val soFarIdx = cursor.getColumnIndex(android.app.DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val totalIdx = cursor.getColumnIndex(android.app.DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            while (cursor.moveToNext()) {
                                val id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L
                                val title = if (titleIdx >= 0) cursor.getString(titleIdx) ?: "Downloading..." else "Downloading..."
                                val bytesDownloaded = if (soFarIdx >= 0) cursor.getLong(soFarIdx) else 0L
                                val bytesTotal = if (totalIdx >= 0) cursor.getLong(totalIdx) else 0L
                                val progress = if (bytesTotal > 0) ((bytesDownloaded * 100) / bytesTotal).toInt() else 0
                                currentActive.add(ActiveDownload(id, title, progress, bytesDownloaded, bytesTotal))
                            }
                        }
                    } catch (e: Exception) { }
                }

                val dir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "Genga World")
                val scanned = if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.filter { it.extension.equals("mp4", ignoreCase = true) }?.sortedBy { it.name } ?: emptyList()
                } else {
                    emptyList()
                }

                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    viewModel.activeDownloads = currentActive
                    if (viewModel.downloadedFiles.size != scanned.size || viewModel.downloadedFiles.map { it.name } != scanned.map { it.name }) {
                        viewModel.downloadedFiles = scanned
                    }
                    viewModel.isDownloadScanLoaded = true
                }
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        if (!isScanLoaded && downloadedFiles.isEmpty() && activeDownloads.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CinematicRed, modifier = Modifier.size(36.dp))
            }
        } else if (downloadedFiles.isEmpty() && activeDownloads.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Download,
                    contentDescription = "Downloads",
                    tint = TextSecondary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (hasPermission) "No Downloads Yet" else "Storage Permission Required",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Downloaded media will appear here.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                Text(
                    text = "My Downloads",
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp)
                )
                androidx.compose.foundation.lazy.LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (activeDownloads.isNotEmpty()) {
                        item {
                            Text("Downloading...", color = CinematicRed, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
                        }
                        items(activeDownloads) { active ->
                            val gengaDir = remember { java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "Genga World") }
                            val safeActiveTitle = remember(active.title) { active.title.replace(Regex("[^a-zA-Z0-9.-]"), "_") }
                            val safeShowPrefix = remember(active.title) {
                                val match = Regex("(.*?)(_S\\d+E\\d+.*|$)").find(safeActiveTitle)
                                match?.groupValues?.get(1)?.trim() ?: safeActiveTitle
                            }
                            val activePosterFile = remember(active.title) {
                                val titleFile = java.io.File(gengaDir, "$safeActiveTitle.jpg")
                                if (titleFile.exists()) titleFile else {
                                    val showFile = java.io.File(gengaDir, "$safeShowPrefix.jpg")
                                    if (showFile.exists()) showFile else null
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(com.example.ui.theme.ObsidianCard, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (activePosterFile != null && activePosterFile.exists()) {
                                    AsyncImage(
                                        model = coil.request.ImageRequest.Builder(LocalContext.current)
                                            .data(activePosterFile)
                                            .crossfade(100)
                                            .memoryCacheKey(activePosterFile.absolutePath)
                                            .build(),
                                        contentDescription = "Poster",
                                        modifier = Modifier.size(56.dp, 42.dp).clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp, 42.dp)
                                            .background(ObsidianDark, RoundedCornerShape(6.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Filled.Download, contentDescription = "Downloading", tint = CinematicRed, modifier = Modifier.size(20.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = active.title,
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = { if (active.progress > 0) active.progress / 100f else 0f },
                                        modifier = Modifier.fillMaxWidth().height(4.dp),
                                        color = CinematicRed,
                                        trackColor = ObsidianDark
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${active.progress}% (${(active.downloadedBytes / (1024 * 1024))}MB / ${if (active.totalBytes > 0) (active.totalBytes / (1024 * 1024)).toString() + "MB" else "Unknown"})",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                    if (downloadedFiles.isNotEmpty()) {
                        item {
                            Text("Completed", color = TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                        }
                        val groupedFiles = downloadedFiles.groupBy { file ->
                            val name = file.nameWithoutExtension
                            val match = Regex("(.*?)(_S\\d+E\\d+.*|$)").find(name)
                            match?.groupValues?.get(1)?.replace("_", " ")?.trim() ?: name
                        }

                        items(groupedFiles.keys.toList()) { showName ->
                            val filesForShow = groupedFiles[showName] ?: emptyList()
                            val isExpanded = expandedShows.contains(showName)
                            val gengaDir = remember { java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "Genga World") }
                            val safeShowPrefix = remember(showName) { showName.replace(Regex("[^a-zA-Z0-9.-]"), "_") }

                            val posterFile = remember(showName, filesForShow) {
                                val showLevel = java.io.File(gengaDir, "$safeShowPrefix.jpg")
                                if (showLevel.exists()) {
                                    showLevel
                                } else {
                                    filesForShow.firstNotNullOfOrNull { f ->
                                        val p = java.io.File(gengaDir, "${f.nameWithoutExtension}.jpg")
                                        if (p.exists()) p else null
                                    }
                                }
                            }
                            
                            Column(modifier = Modifier.fillMaxWidth().background(com.example.ui.theme.ObsidianCard, RoundedCornerShape(10.dp))) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (filesForShow.size == 1) {
                                                playerPickerFile = filesForShow.first()
                                            } else {
                                                expandedShows = if (isExpanded) expandedShows - showName else expandedShows + showName
                                            }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (posterFile != null && posterFile.exists()) {
                                        AsyncImage(
                                            model = coil.request.ImageRequest.Builder(LocalContext.current)
                                                .data(posterFile)
                                                .crossfade(100)
                                                .memoryCacheKey(posterFile.absolutePath)
                                                .build(),
                                            contentDescription = "Poster",
                                            modifier = Modifier.size(56.dp, 84.dp).clip(RoundedCornerShape(6.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier.size(56.dp, 84.dp).background(ObsidianDark, RoundedCornerShape(6.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = CinematicRed, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = showName,
                                            color = TextPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = if (filesForShow.size > 1) "${filesForShow.size} Episodes" else "${(filesForShow.first().length() / (1024 * 1024))} MB",
                                            color = TextSecondary,
                                            fontSize = 13.sp
                                        )
                                    }
                                    if (filesForShow.size > 1) {
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                            contentDescription = "Expand",
                                            tint = TextSecondary,
                                            modifier = Modifier.padding(4.dp)
                                        )
                                    } else if (filesForShow.isNotEmpty()) {
                                        val singleFile = filesForShow.first()
                                        IconButton(onClick = {
                                            coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                                val singlePoster = java.io.File(gengaDir, "${singleFile.nameWithoutExtension}.jpg")
                                                if (singlePoster.exists()) singlePoster.delete()
                                                val showPoster = java.io.File(gengaDir, "$safeShowPrefix.jpg")
                                                if (showPoster.exists()) showPoster.delete()
                                                gengaDir.listFiles()?.filter { it.extension.equals("jpg", ignoreCase = true) && it.nameWithoutExtension.startsWith(safeShowPrefix) }?.forEach { it.delete() }
                                                singleFile.delete()
                                                viewModel.scanDownloadedFiles()
                                            }
                                        }) {
                                            Icon(
                                                Icons.Filled.Delete,
                                                contentDescription = "Delete",
                                                tint = TextSecondary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                                
                                if (isExpanded && filesForShow.size > 1) {
                                    Column(modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
                                        filesForShow.forEach { file ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 3.dp)
                                                    .background(ObsidianDark, RoundedCornerShape(6.dp))
                                                    .clickable { playerPickerFile = file }
                                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = CinematicRed, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    val epMatch = Regex("_S(\\d+)E(\\d+)").find(file.nameWithoutExtension)
                                                    val epName = if (epMatch != null) "Season ${epMatch.groupValues[1]} Episode ${epMatch.groupValues[2]}" else file.nameWithoutExtension
                                                    Text(text = epName, color = TextPrimary, fontSize = 13.sp)
                                                    Text(text = "${(file.length() / (1024 * 1024))} MB", color = TextSecondary, fontSize = 11.sp)
                                                }
                                                IconButton(onClick = { 
                                                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                                        if (filesForShow.size <= 1) {
                                                            // Last episode remaining: clean up posters
                                                            val epPoster = java.io.File(gengaDir, "${file.nameWithoutExtension}.jpg")
                                                            if (epPoster.exists()) epPoster.delete()
                                                            val showPoster = java.io.File(gengaDir, "$safeShowPrefix.jpg")
                                                            if (showPoster.exists()) showPoster.delete()
                                                            gengaDir.listFiles()?.filter { it.extension.equals("jpg", ignoreCase = true) && it.nameWithoutExtension.startsWith(safeShowPrefix) }?.forEach { it.delete() }
                                                        }
                                                        // When multiple episodes exist, ONLY delete the video file, preserving posters for the remaining episodes
                                                        file.delete()
                                                        viewModel.scanDownloadedFiles()
                                                    }
                                                }) {
                                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if (playerPickerFile != null) {
            val fileToPlay = playerPickerFile!!
            val externalPlayers = remember(context) { getInstalledVideoPlayers(context) }
            val appIcon = remember(context) {
                try { context.packageManager.getApplicationIcon(context.packageName) } catch (e: Exception) { null }
            }

            ModalBottomSheet(
                onDismissRequest = { playerPickerFile = null },
                containerColor = com.example.ui.theme.ObsidianCard,
                contentColor = TextPrimary,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                dragHandle = {
                    Box(
                        modifier = Modifier
                            .padding(top = 12.dp, bottom = 8.dp)
                            .size(width = 40.dp, height = 4.dp)
                            .background(TextSecondary.copy(alpha = 0.4f), RoundedCornerShape(2.dp))
                    )
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Text(
                        text = "Play With",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    val epMatch = Regex("_S(\\d+)E(\\d+)").find(fileToPlay.nameWithoutExtension)
                    val displayName = if (epMatch != null) {
                        val showPrefix = fileToPlay.nameWithoutExtension.substringBefore("_S").replace("_", " ")
                        "$showPrefix • Season ${epMatch.groupValues[1]} Episode ${epMatch.groupValues[2]}"
                    } else {
                        fileToPlay.nameWithoutExtension.replace("_", " ")
                    }
                    Text(
                        text = displayName,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
                    )

                    // 1. Genga World Internal Player
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianDark)
                            .clickable {
                                viewModel.playingDownloadedFile = fileToPlay
                                playerPickerFile = null
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (appIcon != null) {
                            AsyncImage(
                                model = appIcon,
                                contentDescription = "Genga World",
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(CinematicRed.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = CinematicRed, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Genga World Player",
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "IN-APP",
                                    color = CinematicRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .background(CinematicRed.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "Built-in cinema player with controls",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = CinematicRed)
                    }

                    if (externalPlayers.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Other Installed Players",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        externalPlayers.forEach { player ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ObsidianDark)
                                    .clickable {
                                        playerPickerFile = null
                                        openInExternalPlayer(context, fileToPlay, player)
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (player.icon != null) {
                                    AsyncImage(
                                        model = player.icon,
                                        contentDescription = player.name,
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(10.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(com.example.ui.theme.ObsidianCard, RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = TextSecondary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = player.name,
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "External player",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }

                    // System Chooser Option
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianDark)
                            .clickable {
                                playerPickerFile = null
                                openInExternalPlayer(context, fileToPlay, null)
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(com.example.ui.theme.ObsidianCard, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.MoreHoriz, contentDescription = "More", tint = TextPrimary)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "System Dialog / More Apps...",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Choose from standard Android popup",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
        
    }
}

@Composable
fun OfflinePlayerScreen(fileToPlay: java.io.File, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val epMatch = Regex("_S(\\d+)E(\\d+)").find(fileToPlay.nameWithoutExtension)
    val displayTitle = if (epMatch != null) {
        val showPrefix = fileToPlay.nameWithoutExtension.substringBefore("_S").replace("_", " ")
        "$showPrefix - S${epMatch.groupValues[1]} E${epMatch.groupValues[2]}"
    } else {
        fileToPlay.nameWithoutExtension.replace("_", " ")
    }

    var isOfflineControllerVisible by remember { mutableStateOf(true) }
    var isOfflinePlaying by remember { mutableStateOf(true) }
    var currentOfflineProgressMs by remember { mutableStateOf(0L) }
    var offlineDurationMs by remember { mutableStateOf(0L) }
    var isOfflineBuffering by remember { mutableStateOf(false) }

    // Double-Tap Gesture Indicator States
    var offlineDoubleTapSide by remember { mutableStateOf<String?>(null) }
    var offlineDoubleTapText by remember { mutableStateOf<String?>(null) }
    var offlineGestureTrigger by remember { mutableStateOf(0L) }

    val offlineConfiguration = androidx.compose.ui.platform.LocalConfiguration.current
    val isOfflineFullscreen = offlineConfiguration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val offlineActivity = context as? android.app.Activity
    val isOfflineInPip = offlineActivity?.isInPictureInPictureMode ?: false

    val exoPlayer = remember(fileToPlay) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(fileToPlay)))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(fileToPlay) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isOfflineBuffering = (state == androidx.media3.common.Player.STATE_BUFFERING)
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                isOfflinePlaying = playWhenReady
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            offlineActivity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            offlineActivity?.window?.decorView?.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    // Keep system bars hidden when in landscape fullscreen
    LaunchedEffect(isOfflineFullscreen) {
        if (offlineActivity != null) {
            if (isOfflineFullscreen) {
                offlineActivity.window.decorView.systemUiVisibility = (
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            } else {
                offlineActivity.window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }

    // Progress ticker
    LaunchedEffect(isOfflinePlaying) {
        if (isOfflinePlaying) {
            while (true) {
                val pos = exoPlayer.currentPosition
                val dur = exoPlayer.duration
                if (dur > 0) {
                    currentOfflineProgressMs = pos
                    offlineDurationMs = dur
                }
                delay(1000)
            }
        }
    }

    // Auto-hide controller
    LaunchedEffect(isOfflineControllerVisible, isOfflinePlaying) {
        if (isOfflineControllerVisible && isOfflinePlaying) {
            delay(4000)
            isOfflineControllerVisible = false
        }
    }

    // Reset gesture animation
    LaunchedEffect(offlineGestureTrigger) {
        if (offlineGestureTrigger > 0L) {
            delay(750)
            offlineDoubleTapSide = null
            offlineDoubleTapText = null
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { ctx ->
                val view = android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.texture_player_view, null) as androidx.media3.ui.PlayerView
                view.keepScreenOn = true
                view.isHapticFeedbackEnabled = false
                view.isSoundEffectsEnabled = false
                view.useController = false
                view.apply {
                    subtitleView?.setViewType(androidx.media3.ui.SubtitleView.VIEW_TYPE_CANVAS)
                    val cleanStyle = androidx.media3.ui.CaptionStyleCompat(
                        android.graphics.Color.WHITE,
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT,
                        androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                        android.graphics.Color.BLACK,
                        null
                    )
                    subtitleView?.setStyle(cleanStyle)
                    player = exoPlayer
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Universal Gestures Layer (Single tap toggles UI, Double tap Left = -5s, Center = Pause/Play, Right = +10s)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            isOfflineControllerVisible = !isOfflineControllerVisible
                        },
                        onDoubleTap = { tapOffset: androidx.compose.ui.geometry.Offset ->
                            val width = size.width.toFloat()
                            val x = tapOffset.x
                            val leftBoundary = width * 0.35f
                            val rightBoundary = width * 0.65f

                            when {
                                x < leftBoundary -> {
                                    // Left: rewind 5s
                                    val current = exoPlayer.currentPosition
                                    val target = (current - 5000L).coerceAtLeast(0L)
                                    exoPlayer.seekTo(target)
                                    offlineDoubleTapSide = "left"
                                    offlineDoubleTapText = "-5s"
                                    offlineGestureTrigger = System.currentTimeMillis()
                                }
                                x > rightBoundary -> {
                                    // Right: forward 10s
                                    val current = exoPlayer.currentPosition
                                    val dur = exoPlayer.duration
                                    val target = if (dur > 0) (current + 10000L).coerceAtMost(dur) else current + 10000L
                                    exoPlayer.seekTo(target)
                                    offlineDoubleTapSide = "right"
                                    offlineDoubleTapText = "+10s"
                                    offlineGestureTrigger = System.currentTimeMillis()
                                }
                                else -> {
                                    // Center: toggle play / pause
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                        isOfflinePlaying = false
                                        offlineDoubleTapSide = "center"
                                        offlineDoubleTapText = "PAUSE"
                                    } else {
                                        exoPlayer.play()
                                        isOfflinePlaying = true
                                        offlineDoubleTapSide = "center"
                                        offlineDoubleTapText = "PLAY"
                                    }
                                    offlineGestureTrigger = System.currentTimeMillis()
                                }
                            }
                        }
                    )
                }
        )

        // Double-Tap Animated Feedback Badges
        androidx.compose.animation.AnimatedVisibility(
            visible = offlineDoubleTapSide != null,
            enter = fadeIn(tween(150)) + scaleIn(tween(150)),
            exit = fadeOut(tween(250)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                when (offlineDoubleTapSide) {
                    "left" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.38f)
                                .align(Alignment.CenterStart)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.White.copy(alpha = 0.22f), Color.Transparent)
                                )
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Replay5, contentDescription = "Rewind 5s", tint = Color.White, modifier = Modifier.size(46.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = offlineDoubleTapText ?: "-5s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    "right" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.38f)
                                .align(Alignment.CenterEnd)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.22f))
                                )
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(46.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = offlineDoubleTapText ?: "+10s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    "center" -> {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .align(Alignment.Center)
                                .background(Color.Black.copy(alpha = 0.65f), shape = RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    if (isOfflinePlaying) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                    contentDescription = "Play/Pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = offlineDoubleTapText ?: "",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Custom Playback Controller Overlay (matching normal player without settings & download)
        androidx.compose.animation.AnimatedVisibility(
            visible = isOfflineControllerVisible && !isOfflineInPip,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top Bar: Back button on the left, Title in center
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopStart)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)
                            )
                        )
                        .statusBarsPadding()
                        .clickable(enabled = false) {}
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        offlineActivity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        offlineActivity?.window?.decorView?.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
                        onDismiss()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Close Player", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = displayTitle,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Center Buffering Spinner
                if (isOfflineBuffering) {
                    CircularProgressIndicator(
                        color = CinematicRed,
                        modifier = Modifier.align(Alignment.Center).size(48.dp)
                    )
                }

                // Bottom Controls Row: Play/Pause, Seekbar, Duration, PIP, Fullscreen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                            )
                        )
                        .navigationBarsPadding()
                        .clickable(enabled = false) {}
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Play/Pause Button
                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                                isOfflinePlaying = false
                            } else {
                                exoPlayer.play()
                                isOfflinePlaying = true
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            if (isOfflinePlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Progress Slider
                    Slider(
                        value = currentOfflineProgressMs.toFloat(),
                        onValueChange = { currentOfflineProgressMs = it.toLong() },
                        onValueChangeFinished = { exoPlayer.seekTo(currentOfflineProgressMs) },
                        valueRange = 0f..maxOf(1f, offlineDurationMs.toFloat()),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color.Gray.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                    )

                    // Position / Duration text
                    Text(
                        text = "${formatTime(currentOfflineProgressMs)}/${formatTime(offlineDurationMs)}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    // PIP Button
                    IconButton(
                        onClick = {
                            if (offlineActivity != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                offlineActivity.enterPictureInPictureMode(
                                    android.app.PictureInPictureParams.Builder().build()
                                )
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Filled.PictureInPicture,
                            contentDescription = "PiP Mode",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Fullscreen Toggle Button
                    IconButton(
                        onClick = {
                            if (offlineActivity != null) {
                                if (!isOfflineFullscreen) {
                                    offlineActivity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    offlineActivity.window.decorView.systemUiVisibility = (
                                        android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                        or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                        or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                    )
                                } else {
                                    offlineActivity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    offlineActivity.window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
                                }
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isOfflineFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            contentDescription = "Toggle Fullscreen",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MovieViewModel, onNavigateToHistory: () -> Unit = {}, onNavigateToManageCategories: () -> Unit = {}) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var isRegisterMode by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }
    var showLoginForm by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val history by viewModel.historyList.collectAsState()
    
    val groupedHistory = remember(history) {
        history.groupBy { it.subjectId }.map { it.value.first() }
    }

    LaunchedEffect(viewModel.isLoggedIn) {
        if (viewModel.isLoggedIn) {
            viewModel.checkUserSession()
            showLoginForm = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(horizontal = 16.dp, vertical = 24.dp)
    ) {
        if (viewModel.isLoggedIn || !showLoginForm) {
            val user = viewModel.currentUserProfile
            var showEditNicknameDialog by remember { mutableStateOf(false) }
            var editNickname by remember { mutableStateOf(user?.nickname ?: "") }

            val photoPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
            ) { uri: android.net.Uri? ->
                if (uri != null) {
                    try {
                        val inputStream = context.contentResolver.openInputStream(uri)
                        val bytes = inputStream?.readBytes()
                        if (bytes != null) {
                            viewModel.uploadAvatarAndModifyProfile(
                                nickname = user?.nickname ?: "",
                                imageBytes = bytes,
                                onSuccess = {
                                    Toast.makeText(context, "Avatar updated", Toast.LENGTH_SHORT).show()
                                },
                                onError = { err ->
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Failed to load image: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            if (showEditNicknameDialog && viewModel.isLoggedIn) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { showEditNicknameDialog = false },
                    title = { Text("Edit Nickname", color = TextPrimary) },
                    text = {
                        androidx.compose.material3.OutlinedTextField(
                            value = editNickname,
                            onValueChange = { editNickname = it },
                            label = { Text("Nickname") },
                            textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary),
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.updateProfile(
                                    nickname = editNickname,
                                    avatar = user?.avatar ?: "",
                                    onSuccess = {
                                        Toast.makeText(context, "Nickname updated", Toast.LENGTH_SHORT).show()
                                        showEditNicknameDialog = false
                                    },
                                    onError = { err ->
                                        Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                    }
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CinematicRed)
                        ) {
                            Text("Save")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditNicknameDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                    },
                    containerColor = ObsidianCard
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Profile Header Row (Avatar on Left, Nickname & ID on Right)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .clickable {
                            if (viewModel.isLoggedIn) {
                                editNickname = user?.nickname ?: ""
                                showEditNicknameDialog = true
                            } else {
                                showLoginForm = true
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar
                    if (viewModel.isLoggedIn) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .background(ObsidianCard, shape = CircleShape)
                                .clickable {
                                    photoPickerLauncher.launch("image/*")
                                }
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (user?.avatar?.isNotEmpty() == true) {
                                AsyncImage(
                                    model = user.avatar,
                                    contentDescription = "Avatar",
                                    contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.AccountCircle,
                                    contentDescription = "User Avatar",
                                    tint = CinematicRed,
                                    modifier = Modifier.size(60.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))
                    }

                    // Nickname and ID
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (viewModel.isLoggedIn && user?.nickname?.isNotEmpty() == true) user.nickname else "Log in to your account",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (viewModel.isLoggedIn) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "ID: ${if (user?.userId?.isNotEmpty() == true) user.userId else "00000000"}",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    if (!viewModel.isLoggedIn) {
                        Button(
                            onClick = { showLoginForm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Log In", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))

                // Watch History Section
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                    ) {
                        // Title Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToHistory() }
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = "Watch History",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Watch History",
                                    fontSize = 16.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(
                                imageVector = Icons.Filled.ChevronRight,
                                contentDescription = "Navigate",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // History Posters Row
                        if (groupedHistory.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(groupedHistory.take(5)) { item ->
                                    Box(
                                        modifier = Modifier
                                            .width(140.dp)
                                            .height(80.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.DarkGray)
                                            .clickable {
                                                // Quick jump to detail could be added here
                                                onNavigateToHistory()
                                            }
                                    ) {
                                        AsyncImage(
                                            model = item.poster,
                                            contentDescription = item.name,
                                            contentScale = ContentScale.Crop, placeholder = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray), error = androidx.compose.ui.graphics.painter.ColorPainter(androidx.compose.ui.graphics.Color.DarkGray),
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        // Gradient at bottom
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.verticalGradient(
                                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)),
                                                        startY = 50f
                                                    )
                                                )
                                        )
                                        // Title text over image
                                        Text(
                                            text = item.name,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Location / Region Selection Section
                var showLocationDialog by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLocationDialog = true }
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = "Location",
                                tint = TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Location",
                                    fontSize = 16.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = when (viewModel.customCountryIso) {
                                        "us" -> "United States"
                                        "br" -> "Brazil"
                                        "ru" -> "Russia"
                                        else -> "India"
                                    },
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Manage Categories Section
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToManageCategories() }
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.List,
                                contentDescription = "Manage Categories",
                                tint = TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Manage Categories",
                                    fontSize = 16.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Add or remove Home Feed tabs",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Filled.ChevronRight,
                            contentDescription = "Navigate",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Telegram Community Section
                var showSettingsTelegramDialog by remember { mutableStateOf(false) }
                if (showSettingsTelegramDialog) {
                    TelegramJoinDialog(
                        onDismiss = { showSettingsTelegramDialog = false },
                        telegramUrl = "https://t.me/Gengaworldofficial"
                    )
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSettingsTelegramDialog = true }
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Send,
                                contentDescription = "Telegram",
                                tint = Color(0xFF0EA2DE),
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(-25f)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Join Telegram Channel",
                                    fontSize = 16.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Get early access, requests & updates",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Filled.ChevronRight,
                            contentDescription = "Navigate",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Check for Updates Section
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !viewModel.isCheckingUpdate) {
                                viewModel.checkForUpdates(isManualCheck = true) { hasUpdate, message ->
                                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.SystemUpdate,
                                contentDescription = "Check for Updates",
                                tint = CinematicRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Check for Updates",
                                    fontSize = 16.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                val appVersion = remember {
                                    try {
                                        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "2.0"
                                    } catch (e: Exception) { "2.0" }
                                }
                                Text(
                                    text = if (viewModel.isCheckingUpdate) "Checking latest version..." else "Current: v$appVersion",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                        if (viewModel.isCheckingUpdate) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CinematicRed,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.ChevronRight,
                                contentDescription = "Check",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                if (showLocationDialog) {
                    AlertDialog(
                        onDismissRequest = { showLocationDialog = false },
                        title = { Text("Select Region", color = TextPrimary, fontWeight = FontWeight.Bold) },
                        text = {
                            Column {
                                val regions = listOf(
                                    Triple("90101", "us", "United States"),
                                    Triple("40401", "in", "India"),
                                    Triple("72402", "br", "Brazil"),
                                    Triple("25001", "ru", "Russia")
                                )
                                regions.forEach { reg ->
                                    val isSelected = viewModel.customMcc == reg.first && viewModel.customCountryIso == reg.second
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { 
                                                viewModel.applyCustomSandbox(reg.first, reg.second)
                                                showLocationDialog = false
                                            }
                                            .padding(vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { 
                                                viewModel.applyCustomSandbox(reg.first, reg.second)
                                                showLocationDialog = false
                                            },
                                            colors = RadioButtonDefaults.colors(selectedColor = CinematicRed)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(reg.third, color = TextPrimary, fontSize = 16.sp)
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showLocationDialog = false }) {
                                Text("Close", color = TextSecondary)
                            }
                        },
                        containerColor = ObsidianCard
                    )
                }

                Spacer(modifier = Modifier.height(30.dp))

                if (viewModel.isLoggedIn) {
                    Button(
                        onClick = {
                            viewModel.logoutUser {
                                Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .align(Alignment.CenterHorizontally)
                            .height(50.dp)
                            .testTag("logout_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.ExitToApp, contentDescription = "Log Out")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
                
                Spacer(modifier = Modifier.height(80.dp))
            }
        } else {
            // Sign In / Register Card Layout
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Close button to return to profile
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.Start
                ) {
                    IconButton(onClick = { showLoginForm = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextPrimary)
                    }
                }

                // Brand Header
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = "MovieBox Auth",
                    tint = CinematicRed,
                    modifier = Modifier.size(64.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isRegisterMode) "Create Account" else "Welcome Back",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Text(
                    text = if (isRegisterMode) "Sign up to sync your history & favorites" else "Sign in to access premium media content",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 4.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (errorMessage.isNotEmpty()) {
                            Text(
                                text = errorMessage,
                                color = CinematicRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }

                        if (statusMessage.isNotEmpty()) {
                            Text(
                                text = statusMessage,
                                color = AccentAmber,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }

                        // Email Address Input
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("email_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CinematicRed,
                                unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
                                focusedLabelColor = CinematicRed,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Password Input
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CinematicRed,
                                unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
                                focusedLabelColor = CinematicRed,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // OTP Code Input (only in Register Mode)
                        if (isRegisterMode) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = otp,
                                    onValueChange = { otp = it },
                                    label = { Text("OTP Code") },
                                    leadingIcon = { Icon(Icons.Filled.Check, contentDescription = "OTP Code") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("otp_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CinematicRed,
                                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
                                        focusedLabelColor = CinematicRed,
                                        unfocusedLabelColor = TextSecondary,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Button(
                                    onClick = {
                                        if (email.isEmpty()) {
                                            errorMessage = "Please enter your email to request OTP"
                                            return@Button
                                        }
                                        if (!email.contains("@") || !email.contains(".")) {
                                            errorMessage = "Please enter a valid email address"
                                            return@Button
                                        }
                                        viewModel.requestOtp(email, isRegister = true, onSuccess = {
                                            errorMessage = ""
                                            statusMessage = "OTP sent to your email successfully!"
                                        }, onError = { err ->
                                            statusMessage = ""
                                            errorMessage = err
                                        })
                                    },
                                    modifier = Modifier
                                        .height(56.dp)
                                        .testTag("request_otp_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = ObsidianDark),
                                    border = BorderStroke(1.dp, CinematicRed),
                                    shape = RoundedCornerShape(12.dp),
                                    enabled = !viewModel.isAuthLoading
                                ) {
                                    Text("Get OTP", color = CinematicRed, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Submit Button
                        Button(
                            onClick = {
                                if (email.isEmpty() || password.isEmpty()) {
                                    errorMessage = "Email and Password cannot be empty"
                                    return@Button
                                }
                                if (!email.contains("@") || !email.contains(".")) {
                                    errorMessage = "Please enter a valid email address"
                                    return@Button
                                }
                                if (isRegisterMode) {
                                    if (otp.isEmpty()) {
                                        errorMessage = "Please enter the OTP verification code"
                                        return@Button
                                    }
                                    viewModel.registerAccount(email, password, otp, onSuccess = {
                                        Toast.makeText(context, "Account created successfully!", Toast.LENGTH_SHORT).show()
                                    }, onError = { err ->
                                        errorMessage = err
                                    })
                                } else {
                                    viewModel.loginWithPassword(email, password, onSuccess = {
                                        Toast.makeText(context, "Signed in successfully!", Toast.LENGTH_SHORT).show()
                                    }, onError = { err ->
                                        errorMessage = err
                                    })
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("auth_submit_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CinematicRed),
                            shape = RoundedCornerShape(12.dp),
                            enabled = !viewModel.isAuthLoading
                        ) {
                            if (viewModel.isAuthLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Text(
                                    text = if (isRegisterMode) "Register & Sign In" else "Sign In",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Toggle Sign In vs Register
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isRegisterMode) "Already have an account?" else "Don't have an account?",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    TextButton(
                        onClick = {
                            isRegisterMode = !isRegisterMode
                            errorMessage = ""
                            statusMessage = ""
                        },
                        modifier = Modifier.testTag("toggle_auth_mode")
                    ) {
                        Text(
                            text = if (isRegisterMode) "Sign In" else "Sign Up",
                            color = CinematicRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                if (isRegisterMode) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Powered by MovieBoxPro",
                        color = TextSecondary.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
